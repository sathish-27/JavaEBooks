import React, { createContext, useReducer, useContext, ReactNode } from "react";
import { parseFullName } from "@/lib/utils";

// Define verification steps
export const VERIFICATION_STEPS = {
  FULL_NAME: 0,
  DATE_OF_BIRTH: 1,
  SSN: 2,
  DRIVERS_LICENSE: 3,
  ADDRESS: 4,
  CONTACT_INFO: 5,
  IDV_VERIFICATION: 6,
  OFAC_CHECK: 7,
  ACCOUNT_OPENING: 8,
};

export type ChatMessage = {
  id: string;
  content: string;
  sender: "user" | "system";
  timestamp: Date;
};

export type CustomerInfo = {
  firstName: string;
  middleName?: string;
  lastName: string;
  dateOfBirth: string;
  ssn: string;
  driversLicenseNumber?: string;
  driversLicenseState?: string;
  streetAddress?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  emailAddress?: string;
  phoneNumber?: string;
  customerId?: number;
};

export type VerificationStatus = {
  idvPassed?: boolean;
  ofacPassed?: boolean;
  accountOpened?: boolean;
  failureReason?: string;
  verificationId?: number;
};

export type VerificationState = {
  currentStep: number;
  chatMessages: ChatMessage[];
  customerInfo: CustomerInfo;
  verificationStatus: VerificationStatus;
  isSubmitting: boolean;
  isTyping: boolean;
};

export type VerificationAction =
  | { type: "SET_STEP"; payload: number }
  | { type: "ADD_MESSAGE"; payload: { content: string; sender: "user" | "system" } }
  | { type: "UPDATE_CUSTOMER_INFO"; payload: Partial<CustomerInfo> }
  | { type: "SET_CUSTOMER_ID"; payload: number }
  | { type: "UPDATE_VERIFICATION_STATUS"; payload: Partial<VerificationStatus> }
  | { type: "SET_SUBMITTING"; payload: boolean }
  | { type: "SET_TYPING"; payload: boolean }
  | { type: "RESET_VERIFICATION" };

// Initial state
const initialState: VerificationState = {
  currentStep: VERIFICATION_STEPS.FULL_NAME,
  chatMessages: [
    {
      id: `welcome-1-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      content: "👋 Welcome to SecureBank's Identity Verification Assistant. I'll help you verify your identity to open a new account securely.",
      sender: "system",
      timestamp: new Date(),
    },
    {
      id: `welcome-2-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      content: "I'll need to collect some personal information to verify your identity. This is required by federal regulations and helps protect against fraud. All information is encrypted and handled securely.",
      sender: "system",
      timestamp: new Date(),
    },
    {
      id: `welcome-3-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      content: "Let's start with your full legal name. What is your first name, middle name (if any), and last name?",
      sender: "system",
      timestamp: new Date(),
    },
  ],
  customerInfo: {
    firstName: "",
    middleName: "",
    lastName: "",
    dateOfBirth: "",
    ssn: "",
  },
  verificationStatus: {},
  isSubmitting: false,
  isTyping: false,
};

// Reducer function
function verificationReducer(
  state: VerificationState,
  action: VerificationAction
): VerificationState {
  switch (action.type) {
    case "SET_STEP":
      return {
        ...state,
        currentStep: action.payload,
      };
    case "ADD_MESSAGE":
      return {
        ...state,
        chatMessages: [
          ...state.chatMessages,
          {
            id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            content: action.payload.content,
            sender: action.payload.sender,
            timestamp: new Date(),
          },
        ],
      };
    case "UPDATE_CUSTOMER_INFO":
      return {
        ...state,
        customerInfo: {
          ...state.customerInfo,
          ...action.payload,
        },
      };
    case "SET_CUSTOMER_ID":
      return {
        ...state,
        customerInfo: {
          ...state.customerInfo,
          customerId: action.payload,
        },
      };
    case "UPDATE_VERIFICATION_STATUS":
      return {
        ...state,
        verificationStatus: {
          ...state.verificationStatus,
          ...action.payload,
        },
      };
    case "SET_SUBMITTING":
      return {
        ...state,
        isSubmitting: action.payload,
      };
    case "SET_TYPING":
      return {
        ...state,
        isTyping: action.payload,
      };
    case "RESET_VERIFICATION":
      // Create a fresh state with new message IDs instead of reusing initialState
      return {
        ...initialState,
        chatMessages: [
          {
            id: `welcome-1-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            content: "👋 Welcome to SecureBank's Identity Verification Assistant. I'll help you verify your identity to open a new account securely.",
            sender: "system",
            timestamp: new Date(),
          },
          {
            id: `welcome-2-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            content: "I'll need to collect some personal information to verify your identity. This is required by federal regulations and helps protect against fraud. All information is encrypted and handled securely.",
            sender: "system",
            timestamp: new Date(),
          },
          {
            id: `welcome-3-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            content: "Let's start with your full legal name. What is your first name, middle name (if any), and last name?",
            sender: "system",
            timestamp: new Date(),
          },
        ],
      };
    default:
      return state;
  }
}

// Create context
type VerificationContextType = {
  state: VerificationState;
  dispatch: React.Dispatch<VerificationAction>;
  setFullName: (fullName: string) => void;
  setDateOfBirth: (dob: string) => void;
  setSSN: (ssn: string) => void;
  setDriversLicense: (licenseNumber: string, state: string) => void;
  setAddress: (street: string, city: string, state: string, zipCode: string) => void;
  setContactInfo: (email: string, phone: string) => void;
  addUserMessage: (message: string) => void;
  addSystemMessage: (message: string) => void;
  moveToNextStep: () => void;
  isStepComplete: (step: number) => boolean;
};

const VerificationContext = createContext<VerificationContextType | undefined>(
  undefined
);

// Provider component
export function VerificationProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(verificationReducer, initialState);

  // Helper functions
  const setFullName = (fullName: string) => {
    const { firstName, middleName, lastName } = parseFullName(fullName);
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { firstName, middleName, lastName },
    });
  };

  const setDateOfBirth = (dob: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { dateOfBirth: dob },
    });
  };

  const setSSN = (ssn: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { ssn },
    });
  };

  const setDriversLicense = (licenseNumber: string, state: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { driversLicenseNumber: licenseNumber, driversLicenseState: state },
    });
  };

  const setAddress = (street: string, city: string, state: string, zipCode: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { streetAddress: street, city, state, zipCode },
    });
  };

  const setContactInfo = (email: string, phone: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { emailAddress: email, phoneNumber: phone },
    });
  };

  const addUserMessage = (message: string) => {
    dispatch({
      type: "ADD_MESSAGE",
      payload: { content: message, sender: "user" },
    });
  };

  const addSystemMessage = (message: string) => {
    dispatch({
      type: "ADD_MESSAGE",
      payload: { content: message, sender: "system" },
    });
  };

  const moveToNextStep = () => {
    dispatch({
      type: "SET_STEP",
      payload: state.currentStep + 1,
    });
  };

  const isStepComplete = (step: number): boolean => {
    const { customerInfo, verificationStatus } = state;
    
    switch (step) {
      case VERIFICATION_STEPS.FULL_NAME:
        return !!customerInfo.firstName && !!customerInfo.lastName;
      case VERIFICATION_STEPS.DATE_OF_BIRTH:
        return !!customerInfo.dateOfBirth;
      case VERIFICATION_STEPS.SSN:
        return !!customerInfo.ssn;
      case VERIFICATION_STEPS.DRIVERS_LICENSE:
        return !!customerInfo.driversLicenseNumber && !!customerInfo.driversLicenseState;
      case VERIFICATION_STEPS.ADDRESS:
        return !!customerInfo.streetAddress && !!customerInfo.city && 
               !!customerInfo.state && !!customerInfo.zipCode;
      case VERIFICATION_STEPS.CONTACT_INFO:
        return !!customerInfo.emailAddress && !!customerInfo.phoneNumber;
      case VERIFICATION_STEPS.IDV_VERIFICATION:
        return verificationStatus.idvPassed === true;
      case VERIFICATION_STEPS.OFAC_CHECK:
        return verificationStatus.ofacPassed === true;
      case VERIFICATION_STEPS.ACCOUNT_OPENING:
        return verificationStatus.accountOpened === true;
      default:
        return false;
    }
  };

  return (
    <VerificationContext.Provider
      value={{
        state,
        dispatch,
        setFullName,
        setDateOfBirth,
        setSSN,
        setDriversLicense,
        setAddress,
        setContactInfo,
        addUserMessage,
        addSystemMessage,
        moveToNextStep,
        isStepComplete,
      }}
    >
      {children}
    </VerificationContext.Provider>
  );
}

// Custom hook for using the verification context
export function useVerification() {
  const context = useContext(VerificationContext);
  if (context === undefined) {
    throw new Error(
      "useVerification must be used within a VerificationProvider"
    );
  }
  return context;
}
