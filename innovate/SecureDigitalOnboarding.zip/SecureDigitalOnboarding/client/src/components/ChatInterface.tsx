import React, { useEffect, useRef, useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  useVerification,
  VERIFICATION_STEPS,
} from "@/context/VerificationContext";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  fullNameSchema,
  dateOfBirthSchema,
  ssnSchema,
  driversLicenseSchema,
  addressSchema,
  contactInfoSchema,
  FullNameFormData,
  DateOfBirthFormData,
  SSNFormData,
  DriversLicenseFormData,
  AddressFormData,
  ContactInfoFormData,
} from "@/lib/validation";
import { useToast } from "@/hooks/use-toast";
import { formatDateString } from "@/lib/utils";
import { DateOfBirthForm } from "@/components/DateOfBirthForm";

interface ChatInterfaceProps {
  className?: string;
}

export function ChatInterface({ className }: ChatInterfaceProps) {
  // State for chat input
  const [userInput, setUserInput] = useState("");
  
  // Reference to chat container for scrolling
  const chatContainerRef = useRef<HTMLDivElement>(null);
  
  // Toast hook for notifications
  const { toast } = useToast();
  
  // Verification context
  const {
    state,
    addUserMessage,
    addSystemMessage,
    setFullName,
    setDateOfBirth,
    setSSN,
    setDriversLicense,
    setAddress,
    setContactInfo,
    moveToNextStep,
    isStepComplete,
  } = useVerification();
  
  // Form for full name
  const nameForm = useForm<FullNameFormData>({
    resolver: zodResolver(fullNameSchema),
    defaultValues: {
      fullName: "",
    },
  });
  
  // Form for date of birth
  const dobForm = useForm<DateOfBirthFormData>({
    resolver: zodResolver(dateOfBirthSchema),
    defaultValues: {
      dateOfBirth: "",
    },
  });
  
  // Form for SSN
  const ssnForm = useForm<SSNFormData>({
    resolver: zodResolver(ssnSchema),
    defaultValues: {
      ssn: "",
    },
  });
  
  // Form for driver's license
  const licenseForm = useForm<DriversLicenseFormData>({
    resolver: zodResolver(driversLicenseSchema),
    defaultValues: {
      driversLicenseNumber: "",
      driversLicenseState: "",
    },
  });
  
  // Form for address
  const addressForm = useForm<AddressFormData>({
    resolver: zodResolver(addressSchema),
    defaultValues: {
      streetAddress: "",
      city: "",
      state: "",
      zipCode: "",
    },
  });
  
  // Form for contact information
  const contactForm = useForm<ContactInfoFormData>({
    resolver: zodResolver(contactInfoSchema),
    defaultValues: {
      emailAddress: "",
      phoneNumber: "",
    },
  });
  
  // Scroll to bottom of chat when messages are added
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [state.chatMessages, state.isTyping]);
  
  // Handler for chat form submission
  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userInput.trim()) return;
    
    // Add user message to chat
    addUserMessage(userInput);
    
    // Process input based on current step
    processUserInput(userInput);
    
    // Clear input
    setUserInput("");
  };
  
  // Handle form submissions
  const handleNameSubmit = (data: FullNameFormData) => {
    console.log("Name form submitted:", data);
    addUserMessage(data.fullName);
    setFullName(data.fullName);
    
    // Add system response
    addSystemMessage(
      `Thank you, ${data.fullName.split(' ')[0]}. Now I'll need your date of birth for identity verification. Please provide it in MM/DD/YYYY format.`,
    );
    
    // Reset all subsequent forms
    dobForm.reset({ dateOfBirth: "" });
    ssnForm.reset({ ssn: "" });
    licenseForm.reset({ driversLicenseNumber: "", driversLicenseState: "" });
    addressForm.reset({ streetAddress: "", city: "", state: "", zipCode: "" });
    contactForm.reset({ emailAddress: "", phoneNumber: "" });
    
    // Move to next step
    moveToNextStep();
  };
  
  const handleDobSubmit = (data: DateOfBirthFormData) => {
    console.log("DOB form submitted:", data);
    addUserMessage(formatDateString(data.dateOfBirth));
    setDateOfBirth(data.dateOfBirth);
    
    // Add system response
    addSystemMessage(
      `Thank you. Now I'll need your Social Security Number (SSN). This is required for identity verification and tax purposes. Your SSN is secured with bank-level encryption.`,
    );
    addSystemMessage(
      `Please enter your full 9-digit Social Security Number (XXX-XX-XXXX). This information is needed to verify your identity as required by federal regulations.`,
    );
    moveToNextStep();
  };
  
  const handleSsnSubmit = (data: SSNFormData) => {
    console.log("SSN form submitted, value received and validated");
    addUserMessage("●●●-●●-●●●●"); // Don't show actual SSN in chat
    setSSN(data.ssn);
    
    // Add system response
    addSystemMessage(
      `Thank you. Now I'll need your driver's license information for further verification. Please provide your driver's license number.`,
    );
    moveToNextStep();
  };
  
  const handleLicenseSubmit = (data: DriversLicenseFormData) => {
    console.log("License form submitted:", data);
    addUserMessage(`License: ${data.driversLicenseNumber}, State: ${data.driversLicenseState}`);
    setDriversLicense(data.driversLicenseNumber, data.driversLicenseState);
    
    // Add system response
    addSystemMessage(
      `Thank you. Now I'll need your residential address. Please provide your complete address information.`,
    );
    moveToNextStep();
  };
  
  const handleAddressSubmit = (data: AddressFormData) => {
    console.log("Address form submitted:", data);
    const addressString = `${data.streetAddress}, ${data.city}, ${data.state} ${data.zipCode}`;
    addUserMessage(addressString);
    setAddress(data.streetAddress, data.city, data.state, data.zipCode);
    
    // Add system response
    addSystemMessage(
      `Thank you. Finally, I'll need your contact information. Please provide your email address and phone number.`,
    );
    moveToNextStep();
  };
  
  const handleContactSubmit = (data: ContactInfoFormData) => {
    console.log("Contact form submitted:", data);
    addUserMessage(`Email: ${data.emailAddress}, Phone: ${data.phoneNumber}`);
    setContactInfo(data.emailAddress, data.phoneNumber);
    
    // Add system response
    addSystemMessage(
      `Thank you for providing all your information. I'll now proceed with the identity verification process. This may take a moment.`,
    );
    moveToNextStep();
  };
  
  // Process user input based on current verification step
  const processUserInput = (input: string) => {
    switch (state.currentStep) {
      case VERIFICATION_STEPS.FULL_NAME:
        try {
          const { fullName } = fullNameSchema.parse({ fullName: input });
          setFullName(fullName);
          
          // Add system response
          addSystemMessage(
            `Thank you, ${fullName.split(' ')[0]}. Now I'll need your date of birth for identity verification. Please provide it in MM/DD/YYYY format.`,
          );

          // Reset date of birth form
          dobForm.reset({
            dateOfBirth: ""
          });
            
          moveToNextStep();
        } catch (error) {
          if (error instanceof z.ZodError) {
            addSystemMessage(
              `I'm sorry, but I need your full legal name. Please provide your first and last name.`,
            );
          }
        }
        break;
        
      case VERIFICATION_STEPS.DATE_OF_BIRTH:
        try {
          const { dateOfBirth } = dateOfBirthSchema.parse({ dateOfBirth: input });
          setDateOfBirth(dateOfBirth);
          
          // Add system response
          addSystemMessage(
            `Thank you. Now I'll need your Social Security Number (SSN). This is required for identity verification and tax purposes. Your SSN is secured with bank-level encryption.`,
          );
          addSystemMessage(
            `Please enter your full 9-digit Social Security Number (XXX-XX-XXXX). This information is needed to verify your identity as required by federal regulations.`,
          );
          moveToNextStep();
        } catch (error) {
          if (error instanceof z.ZodError) {
            addSystemMessage(
              `I'm sorry, but I need your date of birth in MM/DD/YYYY format (e.g., 01/31/1990).`,
            );
          }
        }
        break;

      case VERIFICATION_STEPS.SSN:
        try {
          const { ssn } = ssnSchema.parse({ ssn: input });
          setSSN(ssn);

          // Add system response (don't display SSN in chat)
          addSystemMessage(
            `Thank you. Now I'll need your driver's license information for further verification. Please provide your driver's license number.`,
          );
          moveToNextStep();
        } catch (error) {
          if (error instanceof z.ZodError) {
            addSystemMessage(
              `I'm sorry, but I need a valid Social Security Number in the format XXX-XX-XXXX or 9 digits.`,
            );
          }
        }
        break;

      // Handle other steps or general inquiries
      default:
        addSystemMessage(
          `I'm here to help you with the identity verification process. Please continue filling out the required information.`,
        );
    }
  };

  // Render the current step's form
  const renderCurrentStepForm = () => {
    switch (state.currentStep) {
      case VERIFICATION_STEPS.FULL_NAME:
        return (
          <Form {...nameForm}>
            <form
              onSubmit={nameForm.handleSubmit(handleNameSubmit)}
              className="space-y-2"
            >
              <FormField
                control={nameForm.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input
                        placeholder="Enter your full legal name"
                        {...field}
                        className="w-full"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <div className="flex justify-end">
                <Button type="submit" size="sm">
                  Submit
                </Button>
              </div>
            </form>
          </Form>
        );

      case VERIFICATION_STEPS.DATE_OF_BIRTH:
        // Use the new DateOfBirthForm component
        return <DateOfBirthForm onSubmit={handleDobSubmit} />;
        
      case VERIFICATION_STEPS.SSN:
        return (
          <Form {...ssnForm}>
            <form onSubmit={ssnForm.handleSubmit(handleSsnSubmit)} className="space-y-2">
              <FormField
                control={ssnForm.control}
                name="ssn"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        placeholder="XXX-XX-XXXX" 
                        type="password"
                        {...field} 
                        className="w-full"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <div className="text-xs text-neutral-500 mt-1">
                Format: XXX-XX-XXXX (Your SSN is encrypted and secure)
              </div>
              <div className="flex justify-end">
                <Button type="submit" size="sm">
                  Submit
                </Button>
              </div>
            </form>
          </Form>
        );
        
      case VERIFICATION_STEPS.DRIVERS_LICENSE:
        return (
          <Form {...licenseForm}>
            <form onSubmit={licenseForm.handleSubmit(handleLicenseSubmit)} className="space-y-2">
              <FormField
                control={licenseForm.control}
                name="driversLicenseNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        placeholder="Driver's License Number" 
                        {...field} 
                        className="w-full"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={licenseForm.control}
                name="driversLicenseState"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        placeholder="State (2-letter code, e.g., CA)" 
                        {...field} 
                        className="w-full"
                        maxLength={2}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <div className="flex justify-end">
                <Button type="submit" size="sm">
                  Submit
                </Button>
              </div>
            </form>
          </Form>
        );
        
      case VERIFICATION_STEPS.ADDRESS:
        return (
          <Form {...addressForm}>
            <form onSubmit={addressForm.handleSubmit(handleAddressSubmit)} className="space-y-2">
              <FormField
                control={addressForm.control}
                name="streetAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        placeholder="Street Address" 
                        {...field} 
                        className="w-full"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={addressForm.control}
                name="city"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        placeholder="City" 
                        {...field} 
                        className="w-full"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <div className="flex gap-2">
                <FormField
                  control={addressForm.control}
                  name="state"
                  render={({ field }) => (
                    <FormItem className="flex-shrink-0 w-20">
                      <FormControl>
                        <Input 
                          placeholder="State" 
                          {...field} 
                          className="w-full"
                          maxLength={2}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={addressForm.control}
                  name="zipCode"
                  render={({ field }) => (
                    <FormItem className="flex-grow">
                      <FormControl>
                        <Input 
                          placeholder="ZIP Code" 
                          {...field} 
                          className="w-full"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex justify-end">
                <Button type="submit" size="sm">
                  Submit
                </Button>
              </div>
            </form>
          </Form>
        );
        
      case VERIFICATION_STEPS.CONTACT_INFO:
        return (
          <Form {...contactForm}>
            <form onSubmit={contactForm.handleSubmit(handleContactSubmit)} className="space-y-2">
              <FormField
                control={contactForm.control}
                name="emailAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        placeholder="Email Address" 
                        type="email"
                        {...field} 
                        className="w-full"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={contactForm.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        placeholder="Phone Number" 
                        {...field} 
                        className="w-full"
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <div className="flex justify-end">
                <Button type="submit" size="sm">
                  Submit
                </Button>
              </div>
            </form>
          </Form>
        );
        
      // For verification steps, show loading or results
      case VERIFICATION_STEPS.IDV_VERIFICATION:
      case VERIFICATION_STEPS.OFAC_CHECK:
      case VERIFICATION_STEPS.ACCOUNT_OPENING:
        return (
          <div className="mt-2 text-center text-neutral-500 text-sm">
            {state.isSubmitting ? (
              <p>Processing your information...</p>
            ) : (
              <p>Verification in progress...</p>
            )}
          </div>
        );
        
      default:
        return (
          <form onSubmit={handleChatSubmit} className="flex gap-2">
            <Input
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Type a message..."
              className="flex-grow"
            />
            <Button type="submit" size="sm">
              Send
            </Button>
          </form>
        );
    }
  };
  
  // Format chat message timestamp
  const formatMessageTime = (date: Date) => {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = hours % 12 || 12;
    const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
    
    return `${formattedHours}:${formattedMinutes} ${ampm}`;
  };
  
  return (
    <div className={`border rounded-lg shadow-sm overflow-hidden flex flex-col h-[600px] ${className}`}>
      <div className="bg-primary/5 p-3 border-b">
        <h3 className="font-semibold">Identity Verification Assistant</h3>
        <p className="text-sm text-neutral-500">Secure account opening process</p>
      </div>
      
      {/* Chat messages */}
      <div 
        ref={chatContainerRef}
        className="flex-grow overflow-y-auto p-4 space-y-4"
      >
        {state.chatMessages.map((message) => (
          <div 
            key={message.id} 
            className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
          >
            <div 
              className={`max-w-[80%] rounded-lg p-3 ${
                message.sender === "user" 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-neutral-100 dark:bg-neutral-800"
              }`}
            >
              <div className="mb-1">{message.content}</div>
              <div className="text-xs opacity-70 text-right">
                {formatMessageTime(message.timestamp)}
              </div>
            </div>
          </div>
        ))}
        
        {/* Typing indicator */}
        {state.isTyping && (
          <div className="flex justify-start">
            <div className="bg-neutral-100 dark:bg-neutral-800 rounded-lg p-3">
              <div className="flex space-x-1">
                <div className="w-2 h-2 rounded-full bg-neutral-400 animate-bounce"></div>
                <div className="w-2 h-2 rounded-full bg-neutral-400 animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                <div className="w-2 h-2 rounded-full bg-neutral-400 animate-bounce" style={{ animationDelay: "0.4s" }}></div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Input form */}
      <div className="p-4 border-t bg-background">
        {renderCurrentStepForm()}
      </div>
    </div>
  );
}