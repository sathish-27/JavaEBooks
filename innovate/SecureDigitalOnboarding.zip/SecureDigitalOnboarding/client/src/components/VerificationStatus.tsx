import React from "react";
import { useVerification, VERIFICATION_STEPS } from "@/context/VerificationContext";
import { Button } from "@/components/ui/button";
import { getVerificationProgressPercentage } from "@/lib/utils";

interface VerificationStatusProps {
  className?: string;
}

export function VerificationStatus({ className }: VerificationStatusProps) {
  const { state, isStepComplete, dispatch } = useVerification();
  
  // Function to reset verification
  const resetVerification = () => {
    dispatch({ type: "RESET_VERIFICATION" });
  };
  
  // Define all verification steps for display
  const verificationSteps = [
    {
      id: VERIFICATION_STEPS.FULL_NAME,
      title: "Full Legal Name",
      completed: isStepComplete(VERIFICATION_STEPS.FULL_NAME),
      status: isStepComplete(VERIFICATION_STEPS.FULL_NAME) ? "Collected successfully" : "Not started",
      current: state.currentStep === VERIFICATION_STEPS.FULL_NAME,
    },
    {
      id: VERIFICATION_STEPS.DATE_OF_BIRTH,
      title: "Date of Birth",
      completed: isStepComplete(VERIFICATION_STEPS.DATE_OF_BIRTH),
      status: isStepComplete(VERIFICATION_STEPS.DATE_OF_BIRTH) ? "Collected successfully" : "Not started",
      current: state.currentStep === VERIFICATION_STEPS.DATE_OF_BIRTH,
    },
    {
      id: VERIFICATION_STEPS.SSN,
      title: "Social Security Number",
      completed: isStepComplete(VERIFICATION_STEPS.SSN),
      status: isStepComplete(VERIFICATION_STEPS.SSN) ? "Collected successfully" : "Not started",
      current: state.currentStep === VERIFICATION_STEPS.SSN,
    },
    {
      id: VERIFICATION_STEPS.DRIVERS_LICENSE,
      title: "Driver's License",
      completed: isStepComplete(VERIFICATION_STEPS.DRIVERS_LICENSE),
      status: isStepComplete(VERIFICATION_STEPS.DRIVERS_LICENSE) ? "Collected successfully" : "Not started",
      current: state.currentStep === VERIFICATION_STEPS.DRIVERS_LICENSE,
    },
    {
      id: VERIFICATION_STEPS.ADDRESS,
      title: "Current Address",
      completed: isStepComplete(VERIFICATION_STEPS.ADDRESS),
      status: isStepComplete(VERIFICATION_STEPS.ADDRESS) ? "Collected successfully" : "Not started",
      current: state.currentStep === VERIFICATION_STEPS.ADDRESS,
    },
    {
      id: VERIFICATION_STEPS.CONTACT_INFO,
      title: "Contact Information",
      completed: isStepComplete(VERIFICATION_STEPS.CONTACT_INFO),
      status: isStepComplete(VERIFICATION_STEPS.CONTACT_INFO) ? "Collected successfully" : "Not started",
      current: state.currentStep === VERIFICATION_STEPS.CONTACT_INFO,
    },
    {
      id: VERIFICATION_STEPS.IDV_VERIFICATION,
      title: "ID Verification",
      completed: isStepComplete(VERIFICATION_STEPS.IDV_VERIFICATION),
      status: state.verificationStatus.idvPassed === true 
        ? "Verification successful" 
        : state.verificationStatus.idvPassed === false 
          ? "Verification failed" 
          : "Not started",
      current: state.currentStep === VERIFICATION_STEPS.IDV_VERIFICATION,
    },
    {
      id: VERIFICATION_STEPS.OFAC_CHECK,
      title: "OFAC Check",
      completed: isStepComplete(VERIFICATION_STEPS.OFAC_CHECK),
      status: state.verificationStatus.ofacPassed === true 
        ? "Check passed" 
        : state.verificationStatus.ofacPassed === false 
          ? "Check failed" 
          : "Not started",
      current: state.currentStep === VERIFICATION_STEPS.OFAC_CHECK,
    },
    {
      id: VERIFICATION_STEPS.ACCOUNT_OPENING,
      title: "Account Opening",
      completed: isStepComplete(VERIFICATION_STEPS.ACCOUNT_OPENING),
      status: state.verificationStatus.accountOpened === true 
        ? "Account opened" 
        : state.verificationStatus.accountOpened === false 
          ? "Failed to open account" 
          : "Not started",
      current: state.currentStep === VERIFICATION_STEPS.ACCOUNT_OPENING,
    },
  ];
  
  // Calculate progress percentage
  const progressPercentage = getVerificationProgressPercentage(verificationSteps);
  
  // Determine how many steps have been completed
  const completedSteps = verificationSteps.filter(step => step.completed).length;
  const totalSteps = verificationSteps.length;

  return (
    <div className="w-full bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden flex flex-col">
      {/* Status Header */}
      <div className="p-4 border-b border-neutral-200 bg-neutral-50">
        <h2 className="font-medium text-neutral-800">Verification Status</h2>
        <p className="text-sm text-neutral-500">Identity verification process</p>
      </div>
      
      {/* Status Content */}
      <div className="flex-grow p-4 space-y-6 overflow-y-auto">
        {/* Progress Indicator */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-neutral-700">Verification Progress</span>
            <span className="text-sm font-medium text-primary">{completedSteps}/{totalSteps} Steps</span>
          </div>
          <div className="w-full bg-neutral-200 rounded-full h-2.5">
            <div 
              className="bg-primary h-2.5 rounded-full" 
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
        </div>
        
        {/* Status Steps */}
        <div className="space-y-4">
          {verificationSteps.map((step) => (
            <div key={step.id} className={`flex items-start ${!step.completed && !step.current ? 'opacity-50' : ''}`}>
              <div className={`flex-shrink-0 h-8 w-8 flex items-center justify-center rounded-full 
                ${step.completed 
                  ? 'bg-green-500 text-white' 
                  : step.current 
                    ? 'bg-primary text-white' 
                    : 'bg-neutral-300 text-white'}`}
              >
                {step.completed ? (
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                  </svg>
                ) : step.current ? (
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.85.83 6.72 2.21"></path>
                    <path d="M21 3v9h-9"></path>
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                  </svg>
                )}
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-neutral-800">{step.title}</h3>
                <p className="text-xs text-neutral-500">{step.status}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Action Footer */}
      <div className="p-4 border-t border-neutral-200 bg-neutral-50">
        <div className="flex flex-col space-y-3">
          <Button 
            variant="outline" 
            className="w-full flex items-center justify-center" 
            onClick={resetVerification}
            disabled={state.currentStep < VERIFICATION_STEPS.DATE_OF_BIRTH}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path>
              <path d="M3 3v5h5"></path>
            </svg>
            Restart Verification
          </Button>
          <Button 
            variant="outline" 
            className="w-full flex items-center justify-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <path d="M21.2 8.4c.5.38.8.97.8 1.6v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V10a2 2 0 0 1 .8-1.6l8-6a2 2 0 0 1 2.4 0l8 6Z"></path>
              <path d="m22 10-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 10"></path>
            </svg>
            Contact Support
          </Button>
        </div>
      </div>
    </div>
  );
}
