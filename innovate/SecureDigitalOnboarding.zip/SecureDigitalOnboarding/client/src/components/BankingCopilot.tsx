import React from "react";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { ChatInterface } from "./ChatInterface";
import { VerificationStatus } from "./VerificationStatus";
import { VerificationProvider } from "@/context/VerificationContext";

export function BankingCopilot() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <VerificationProvider>
        <main className="flex-grow container mx-auto px-4 py-4 flex flex-col md:flex-row gap-4">
          <div className="w-full md:w-3/5 lg:w-2/3">
            <ChatInterface />
          </div>
          
          <div className="w-full md:w-2/5 lg:w-1/3">
            <VerificationStatus />
          </div>
        </main>
      </VerificationProvider>
      
      <Footer />
    </div>
  );
}
