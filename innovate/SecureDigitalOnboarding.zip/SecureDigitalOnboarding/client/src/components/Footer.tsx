import React from "react";
import { cn } from "@/lib/utils";

interface FooterProps extends React.HTMLAttributes<HTMLElement> {}

export function Footer({ className, ...props }: FooterProps) {
  return (
    <footer className={cn("bg-white border-t border-neutral-200 py-3", className)} {...props}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row justify-between items-center text-xs text-neutral-500">
          <div className="mb-2 sm:mb-0 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
            Your information is protected with bank-level encryption
          </div>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-primary-500">Privacy Policy</a>
            <a href="#" className="hover:text-primary-500">Terms of Service</a>
            <a href="#" className="hover:text-primary-500">Help Center</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
