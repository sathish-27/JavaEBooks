import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User authentication table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Customer information schema for identity verification
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  firstName: text("first_name").notNull(),
  middleName: text("middle_name"),
  lastName: text("last_name").notNull(),
  dateOfBirth: text("date_of_birth").notNull(),
  ssn: text("ssn").notNull(),
  driversLicenseNumber: text("drivers_license_number"),
  driversLicenseState: text("drivers_license_state"),
  streetAddress: text("street_address"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  emailAddress: text("email_address"),
  phoneNumber: text("phone_number"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
  createdAt: true,
});

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

// Verification status schema
export const verifications = pgTable("verifications", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id),
  idvPassed: boolean("idv_passed"),
  ofacPassed: boolean("ofac_passed"),
  accountOpened: boolean("account_opened"),
  failureReason: text("failure_reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertVerificationSchema = createInsertSchema(verifications).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertVerification = z.infer<typeof insertVerificationSchema>;
export type Verification = typeof verifications.$inferSelect;

// Custom schemas for form validation
export const nameSchema = z.object({
  fullName: z.string().min(2, "Full name is required").max(100)
});

export const dateOfBirthSchema = z.object({
  dateOfBirth: z.string().regex(/^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/, "Date must be in MM/DD/YYYY format")
});

export const ssnSchema = z.object({
  ssn: z.string().regex(/^\d{3}-\d{2}-\d{4}$/, "SSN must be in XXX-XX-XXXX format")
});

export const driversLicenseSchema = z.object({
  driversLicenseNumber: z.string().min(1, "Driver's license number is required"),
  driversLicenseState: z.string().length(2, "State must be a 2-letter code")
});

export const addressSchema = z.object({
  streetAddress: z.string().min(1, "Street address is required"),
  city: z.string().min(1, "City is required"),
  state: z.string().length(2, "State must be a 2-letter code"),
  zipCode: z.string().regex(/^\d{5}(-\d{4})?$/, "Zip code must be in XXXXX or XXXXX-XXXX format")
});

export const contactInfoSchema = z.object({
  emailAddress: z.string().email("Invalid email address"),
  phoneNumber: z.string().regex(/^\d{3}-\d{3}-\d{4}$/, "Phone number must be in XXX-XXX-XXXX format")
});

// Chat message schema
export const chatMessageSchema = z.object({
  message: z.string().min(1, "Message cannot be empty"),
  timestamp: z.date().optional(),
  sender: z.enum(["user", "system"])
});

export type ChatMessage = z.infer<typeof chatMessageSchema>;
