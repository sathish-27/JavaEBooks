import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from "axios";
import { insertCustomerSchema, insertVerificationSchema } from "@shared/schema";
import { z } from "zod";

// Mock API endpoints for demonstration purposes
const IDV_API_ENDPOINT = process.env.IDV_API_ENDPOINT || "https://api.idverification.example.com/verify";
const OFAC_API_ENDPOINT = process.env.OFAC_API_ENDPOINT || "https://api.ofac.example.com/check";
const ACCOUNT_OPENING_API_ENDPOINT = process.env.ACCOUNT_OPENING_API_ENDPOINT || "https://api.banking.example.com/accounts/open";

// API Keys
const IDV_API_KEY = process.env.IDV_API_KEY || "idv-api-key";
const OFAC_API_KEY = process.env.OFAC_API_KEY || "ofac-api-key";
const ACCOUNT_API_KEY = process.env.ACCOUNT_API_KEY || "account-api-key";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint for creating/updating customer information
  app.post("/api/customer", async (req, res) => {
    try {
      const customerData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(customerData);
      res.status(201).json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create customer" });
      }
    }
  });

  // API endpoint for updating customer information
  app.patch("/api/customer/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }

      const existingCustomer = await storage.getCustomer(id);
      if (!existingCustomer) {
        return res.status(404).json({ message: "Customer not found" });
      }

      // Partial validation of customer data
      const customerData = insertCustomerSchema.partial().parse(req.body);
      const updatedCustomer = await storage.updateCustomer(id, customerData);
      res.json(updatedCustomer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update customer" });
      }
    }
  });

  // API endpoint for getting customer information
  app.get("/api/customer/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }

      const customer = await storage.getCustomer(id);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }

      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve customer" });
    }
  });

  // API endpoint for IDV verification
  app.post("/api/verify/idv", async (req, res) => {
    try {
      const { customerId, ...customerData } = req.body;
      if (!customerId || isNaN(parseInt(customerId))) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }

      const customer = await storage.getCustomer(parseInt(customerId));
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }

      // Call the IDV API
      try {
        const idvResponse = await axios.post(
          IDV_API_ENDPOINT,
          {
            firstName: customer.firstName,
            middleName: customer.middleName,
            lastName: customer.lastName,
            dateOfBirth: customer.dateOfBirth,
            ssn: customer.ssn,
            driversLicenseNumber: customer.driversLicenseNumber,
            driversLicenseState: customer.driversLicenseState,
            streetAddress: customer.streetAddress,
            city: customer.city,
            state: customer.state,
            zipCode: customer.zipCode
          },
          {
            headers: {
              "Authorization": `Bearer ${IDV_API_KEY}`,
              "Content-Type": "application/json"
            }
          }
        );

        // Create or update verification record
        let verification = await storage.getVerificationByCustomerId(parseInt(customerId));
        if (verification) {
          verification = await storage.updateVerification(verification.id, {
            idvPassed: idvResponse.data.verified === true,
            failureReason: idvResponse.data.verified ? undefined : idvResponse.data.reason
          });
        } else {
          verification = await storage.createVerification({
            customerId: parseInt(customerId),
            idvPassed: idvResponse.data.verified === true,
            ofacPassed: false,
            accountOpened: false,
            failureReason: idvResponse.data.verified ? undefined : idvResponse.data.reason
          });
        }

        res.json({
          verified: idvResponse.data.verified,
          verificationId: verification?.id,
          reason: idvResponse.data.reason
        });
      } catch (error) {
        // In a real implementation, we would handle API errors more gracefully
        console.error("IDV API error:", error);
        
        // Create a failed verification record
        let verification = await storage.getVerificationByCustomerId(parseInt(customerId));
        if (verification) {
          verification = await storage.updateVerification(verification.id, {
            idvPassed: false,
            failureReason: "IDV service unavailable"
          });
        } else {
          verification = await storage.createVerification({
            customerId: parseInt(customerId),
            idvPassed: false,
            ofacPassed: false,
            accountOpened: false,
            failureReason: "IDV service unavailable"
          });
        }
        
        res.status(502).json({ message: "Identity verification service is currently unavailable" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to process identity verification" });
    }
  });

  // API endpoint for OFAC check
  app.post("/api/verify/ofac", async (req, res) => {
    try {
      const { customerId } = req.body;
      if (!customerId || isNaN(parseInt(customerId))) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }

      const customer = await storage.getCustomer(parseInt(customerId));
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }

      // Call the OFAC API
      try {
        const ofacResponse = await axios.post(
          OFAC_API_ENDPOINT,
          {
            firstName: customer.firstName,
            middleName: customer.middleName,
            lastName: customer.lastName,
            dateOfBirth: customer.dateOfBirth,
            ssn: customer.ssn
          },
          {
            headers: {
              "Authorization": `Bearer ${OFAC_API_KEY}`,
              "Content-Type": "application/json"
            }
          }
        );

        // Create or update verification record
        let verification = await storage.getVerificationByCustomerId(parseInt(customerId));
        if (verification) {
          verification = await storage.updateVerification(verification.id, {
            ofacPassed: ofacResponse.data.passed === true,
            failureReason: ofacResponse.data.passed ? verification.failureReason : ofacResponse.data.reason
          });
        } else {
          verification = await storage.createVerification({
            customerId: parseInt(customerId),
            idvPassed: false,
            ofacPassed: ofacResponse.data.passed === true,
            accountOpened: false,
            failureReason: ofacResponse.data.passed ? undefined : ofacResponse.data.reason
          });
        }

        res.json({
          passed: ofacResponse.data.passed,
          verificationId: verification?.id,
          reason: ofacResponse.data.reason
        });
      } catch (error) {
        // In a real implementation, we would handle API errors more gracefully
        console.error("OFAC API error:", error);
        
        // Create a failed verification record
        let verification = await storage.getVerificationByCustomerId(parseInt(customerId));
        if (verification) {
          verification = await storage.updateVerification(verification.id, {
            ofacPassed: false,
            failureReason: verification.failureReason || "OFAC service unavailable"
          });
        } else {
          verification = await storage.createVerification({
            customerId: parseInt(customerId),
            idvPassed: false,
            ofacPassed: false,
            accountOpened: false,
            failureReason: "OFAC service unavailable"
          });
        }
        
        res.status(502).json({ message: "OFAC verification service is currently unavailable" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to process OFAC verification" });
    }
  });

  // API endpoint for opening an account
  app.post("/api/accounts/open", async (req, res) => {
    try {
      const { customerId } = req.body;
      if (!customerId || isNaN(parseInt(customerId))) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }

      const customer = await storage.getCustomer(parseInt(customerId));
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }

      const verification = await storage.getVerificationByCustomerId(parseInt(customerId));
      if (!verification) {
        return res.status(400).json({ message: "Verification not found for customer" });
      }

      if (!verification.idvPassed || !verification.ofacPassed) {
        return res.status(400).json({ 
          message: "Customer has not passed required verifications",
          idvPassed: verification.idvPassed,
          ofacPassed: verification.ofacPassed,
          reason: verification.failureReason
        });
      }

      // Call the account opening API
      try {
        const accountResponse = await axios.post(
          ACCOUNT_OPENING_API_ENDPOINT,
          {
            firstName: customer.firstName,
            middleName: customer.middleName,
            lastName: customer.lastName,
            dateOfBirth: customer.dateOfBirth,
            ssn: customer.ssn,
            streetAddress: customer.streetAddress,
            city: customer.city,
            state: customer.state,
            zipCode: customer.zipCode,
            emailAddress: customer.emailAddress,
            phoneNumber: customer.phoneNumber
          },
          {
            headers: {
              "Authorization": `Bearer ${ACCOUNT_API_KEY}`,
              "Content-Type": "application/json"
            }
          }
        );

        // Update verification record
        await storage.updateVerification(verification.id, {
          accountOpened: true
        });

        res.json({
          accountOpened: true,
          accountId: accountResponse.data.accountId,
          accountNumber: accountResponse.data.accountNumber
        });
      } catch (error) {
        console.error("Account Opening API error:", error);
        res.status(502).json({ message: "Account opening service is currently unavailable" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to open account" });
    }
  });

  // API endpoint for checking verification status
  app.get("/api/verification/:customerId", async (req, res) => {
    try {
      const customerId = parseInt(req.params.customerId);
      if (isNaN(customerId)) {
        return res.status(400).json({ message: "Invalid customer ID" });
      }

      const verification = await storage.getVerificationByCustomerId(customerId);
      if (!verification) {
        return res.status(404).json({ message: "Verification not found" });
      }

      res.json(verification);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve verification status" });
    }
  });

  // API endpoint for creating verification record directly
  app.post("/api/verification", async (req, res) => {
    try {
      const verificationData = insertVerificationSchema.parse(req.body);
      
      // Validate customerId
      const customerId = verificationData.customerId;
      if (!customerId) {
        return res.status(400).json({ message: "Customer ID is required" });
      }
      
      const customer = await storage.getCustomer(customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      // Check if verification already exists
      const existingVerification = await storage.getVerificationByCustomerId(customerId);
      if (existingVerification) {
        // Update existing verification instead of creating a new one
        const updatedVerification = await storage.updateVerification(
          existingVerification.id, 
          verificationData
        );
        return res.json(updatedVerification);
      }
      
      // Create new verification
      const verification = await storage.createVerification(verificationData);
      res.status(201).json(verification);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid verification data", errors: error.errors });
      } else {
        console.error("Error creating verification:", error);
        res.status(500).json({ message: "Failed to create verification record" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
