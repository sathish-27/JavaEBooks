import { 
  users, type User, type InsertUser,
  customers, type Customer, type InsertCustomer,
  verifications, type Verification, type InsertVerification
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Customer operations
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customerData: Partial<InsertCustomer>): Promise<Customer | undefined>;
  
  // Verification operations
  getVerification(id: number): Promise<Verification | undefined>;
  getVerificationByCustomerId(customerId: number): Promise<Verification | undefined>;
  createVerification(verification: InsertVerification): Promise<Verification>;
  updateVerification(id: number, verificationData: Partial<InsertVerification>): Promise<Verification | undefined>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result.length ? result[0] : undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result.length ? result[0] : undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  // Customer operations
  async getCustomer(id: number): Promise<Customer | undefined> {
    const result = await db.select().from(customers).where(eq(customers.id, id));
    return result.length ? result[0] : undefined;
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const result = await db.insert(customers).values(insertCustomer).returning();
    return result[0];
  }

  async updateCustomer(id: number, customerData: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const result = await db
      .update(customers)
      .set(customerData)
      .where(eq(customers.id, id))
      .returning();
    return result.length ? result[0] : undefined;
  }

  // Verification operations
  async getVerification(id: number): Promise<Verification | undefined> {
    const result = await db.select().from(verifications).where(eq(verifications.id, id));
    return result.length ? result[0] : undefined;
  }

  async getVerificationByCustomerId(customerId: number): Promise<Verification | undefined> {
    const result = await db
      .select()
      .from(verifications)
      .where(eq(verifications.customerId, customerId));
    return result.length ? result[0] : undefined;
  }

  async createVerification(insertVerification: InsertVerification): Promise<Verification> {
    const result = await db
      .insert(verifications)
      .values(insertVerification)
      .returning();
    return result[0];
  }

  async updateVerification(id: number, verificationData: Partial<InsertVerification>): Promise<Verification | undefined> {
    // Add updatedAt timestamp
    const dataWithTimestamp = { 
      ...verificationData, 
      updatedAt: new Date() 
    };
    
    const result = await db
      .update(verifications)
      .set(dataWithTimestamp)
      .where(eq(verifications.id, id))
      .returning();
    return result.length ? result[0] : undefined;
  }
}

// In-memory storage implementation (keeping for reference)
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private customers: Map<number, Customer>;
  private verifications: Map<number, Verification>;
  private userId: number;
  private customerId: number;
  private verificationId: number;

  constructor() {
    this.users = new Map();
    this.customers = new Map();
    this.verifications = new Map();
    this.userId = 1;
    this.customerId = 1;
    this.verificationId = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Customer operations
  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.customerId++;
    const now = new Date();
    const customer: Customer = { 
      ...insertCustomer, 
      id,
      userId: insertCustomer.userId ?? null,
      middleName: insertCustomer.middleName ?? null,
      driversLicenseNumber: insertCustomer.driversLicenseNumber ?? null,
      driversLicenseState: insertCustomer.driversLicenseState ?? null,
      streetAddress: insertCustomer.streetAddress ?? null,
      city: insertCustomer.city ?? null,
      state: insertCustomer.state ?? null,
      zipCode: insertCustomer.zipCode ?? null,
      emailAddress: insertCustomer.emailAddress ?? null,
      phoneNumber: insertCustomer.phoneNumber ?? null,
      createdAt: now 
    };
    this.customers.set(id, customer);
    return customer;
  }

  async updateCustomer(id: number, customerData: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const customer = this.customers.get(id);
    if (!customer) return undefined;
    
    const updatedCustomer: Customer = { ...customer, ...customerData };
    this.customers.set(id, updatedCustomer);
    return updatedCustomer;
  }

  // Verification operations
  async getVerification(id: number): Promise<Verification | undefined> {
    return this.verifications.get(id);
  }

  async getVerificationByCustomerId(customerId: number): Promise<Verification | undefined> {
    return Array.from(this.verifications.values()).find(
      (verification) => verification.customerId === customerId,
    );
  }

  async createVerification(insertVerification: InsertVerification): Promise<Verification> {
    const id = this.verificationId++;
    const now = new Date();
    const verification: Verification = { 
      ...insertVerification, 
      id,
      customerId: insertVerification.customerId ?? null,
      idvPassed: insertVerification.idvPassed ?? null,
      ofacPassed: insertVerification.ofacPassed ?? null,
      accountOpened: insertVerification.accountOpened ?? null,
      failureReason: insertVerification.failureReason ?? null,
      createdAt: now,
      updatedAt: now
    };
    this.verifications.set(id, verification);
    return verification;
  }

  async updateVerification(id: number, verificationData: Partial<InsertVerification>): Promise<Verification | undefined> {
    const verification = this.verifications.get(id);
    if (!verification) return undefined;
    
    const now = new Date();
    const updatedVerification: Verification = { 
      ...verification, 
      ...verificationData,
      updatedAt: now 
    };
    this.verifications.set(id, updatedVerification);
    return updatedVerification;
  }
}

// Export the DatabaseStorage instance instead of MemStorage
export const storage = new DatabaseStorage();
