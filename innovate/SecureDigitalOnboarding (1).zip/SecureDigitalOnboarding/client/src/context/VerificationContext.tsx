import React, { createContext, useReducer, useContext, ReactNode } from "react";
import { parseFullName } from "@/lib/utils";
import { AIResponse, sendChatMessage, formatAIResponseToChatMessage } from "@/lib/chatService";

// Define verification steps
export const VERIFICATION_STEPS = {
  WELCOME: 0,
  FULL_NAME: 1,
  DATE_OF_BIRTH: 2,
  SSN: 3,
  DRIVERS_LICENSE: 4,
  ADDRESS: 5,
  CONTACT_INFO: 6,
  IDV_VERIFICATION: 7,
  OFAC_CHECK: 8,
  ACCOUNT_OPENING: 9,
};

export type ChatMessage = {
  id: string;
  content: string;
  sender: "user" | "system";
  timestamp: Date;
};

export type CustomerInfo = {
  firstName: string;
  middleName?: string;
  lastName: string;
  dateOfBirth: string;
  ssn: string;
  driversLicenseNumber?: string;
  driversLicenseState?: string;
  streetAddress?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  emailAddress?: string;
  phoneNumber?: string;
  customerId?: number;
};

export type VerificationStatus = {
  idvPassed?: boolean;
  ofacPassed?: boolean;
  accountOpened?: boolean;
  failureReason?: string;
  verificationId?: number;
  accountNumber?: string;
  routingNumber?: string;
};

export type VerificationState = {
  currentStep: number;
  chatMessages: ChatMessage[];
  customerInfo: CustomerInfo;
  verificationStatus: VerificationStatus;
  isSubmitting: boolean;
  isTyping: boolean;
};

export type VerificationAction =
  | { type: "SET_STEP"; payload: number }
  | { type: "ADD_MESSAGE"; payload: { content: string; sender: "user" | "system" } }
  | { type: "UPDATE_CUSTOMER_INFO"; payload: Partial<CustomerInfo> }
  | { type: "SET_CUSTOMER_ID"; payload: number }
  | { type: "UPDATE_VERIFICATION_STATUS"; payload: Partial<VerificationStatus> }
  | { type: "SET_SUBMITTING"; payload: boolean }
  | { type: "SET_TYPING"; payload: boolean }
  | { type: "RESET_VERIFICATION" }
  | { type: "PROCESS_AI_INTENT"; payload: AIResponse };

// Initial state
const initialState: VerificationState = {
  currentStep: VERIFICATION_STEPS.WELCOME,
  chatMessages: [
    {
      id: `welcome-1-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      content: "👋 Welcome to SecureBank's AI Banking Assistant. I'm here to help you with your banking needs.",
      sender: "system",
      timestamp: new Date(),
    },
    {
      id: `welcome-2-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      content: "I can help you with account opening, loan applications, and answering general banking questions. How can I assist you today?",
      sender: "system",
      timestamp: new Date(),
    },
  ],
  customerInfo: {
    firstName: "",
    middleName: "",
    lastName: "",
    dateOfBirth: "",
    ssn: "",
  },
  verificationStatus: {},
  isSubmitting: false,
  isTyping: false,
};

// Reducer function
function verificationReducer(
  state: VerificationState,
  action: VerificationAction
): VerificationState {
  switch (action.type) {
    case "SET_STEP":
      return {
        ...state,
        currentStep: action.payload,
      };
    case "ADD_MESSAGE":
      return {
        ...state,
        chatMessages: [
          ...state.chatMessages,
          {
            id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            content: action.payload.content,
            sender: action.payload.sender,
            timestamp: new Date(),
          },
        ],
      };
    case "UPDATE_CUSTOMER_INFO":
      return {
        ...state,
        customerInfo: {
          ...state.customerInfo,
          ...action.payload,
        },
      };
    case "SET_CUSTOMER_ID":
      return {
        ...state,
        customerInfo: {
          ...state.customerInfo,
          customerId: action.payload,
        },
      };
    case "UPDATE_VERIFICATION_STATUS":
      return {
        ...state,
        verificationStatus: {
          ...state.verificationStatus,
          ...action.payload,
        },
      };
    case "SET_SUBMITTING":
      return {
        ...state,
        isSubmitting: action.payload,
      };
    case "SET_TYPING":
      return {
        ...state,
        isTyping: action.payload,
      };
    case "RESET_VERIFICATION":
      // Create a fresh state with new message IDs instead of reusing initialState
      return {
        ...initialState,
        currentStep: VERIFICATION_STEPS.WELCOME,
        chatMessages: [
          {
            id: `welcome-1-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            content: "👋 Welcome to SecureBank's AI Banking Assistant. I'm here to help you with your banking needs.",
            sender: "system",
            timestamp: new Date(),
          },
          {
            id: `welcome-2-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            content: "I can help you with account opening, loan applications, and answering general banking questions. How can I assist you today?",
            sender: "system",
            timestamp: new Date(),
          },
        ],
      };
    case "PROCESS_AI_INTENT":
      const aiResponse = action.payload;
      
      // Handle different intents
      let currentStep = state.currentStep;
      
      // Add AI message to chat
      const updatedChatMessages = [
        ...state.chatMessages,
        {
          id: `ai-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
          content: aiResponse.message,
          sender: "system" as "system",
          timestamp: new Date(),
        },
      ];
      
      // For both account opening and loan applications, we need identity verification
      // So we'll use the same flow for both
      
      if (aiResponse.intent === "ACCOUNT_OPENING" || aiResponse.intent === "LOAN_APPLICATION") {
        // Add messages based on intent 
        if (aiResponse.intent === "LOAN_APPLICATION") {
          // Acknowledge loan application but direct to verification
          updatedChatMessages.push({
            id: `loan-info-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            content: `I understand you're interested in a ${aiResponse.loanType?.toLowerCase() || ''} loan. We'll need to complete identity verification first before we can process your loan application.`,
            sender: "system" as "system",
            timestamp: new Date(),
          });
        }
        
        // If we're not already in a verification step, start from the beginning
        if (state.currentStep === VERIFICATION_STEPS.WELCOME || 
            !state.customerInfo.firstName) {
          
          // Add guidance message to start verification
          updatedChatMessages.push({
            id: `account-opening-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
            content: "Let's start with your personal information. Please provide your full legal name (first, middle if any, and last name).",
            sender: "system" as "system",
            timestamp: new Date(),
          });
          
          // Set the current step to FULL_NAME to begin identity verification
          currentStep = VERIFICATION_STEPS.FULL_NAME;
        }
      }
      
      return {
        ...state,
        currentStep,
        chatMessages: updatedChatMessages,
      };
    default:
      return state;
  }
}

// Create context
type VerificationContextType = {
  state: VerificationState;
  dispatch: React.Dispatch<VerificationAction>;
  setFullName: (fullName: string) => void;
  setDateOfBirth: (dob: string) => void;
  setSSN: (ssn: string) => void;
  setDriversLicense: (licenseNumber: string, state: string) => void;
  setAddress: (street: string, city: string, state: string, zipCode: string) => void;
  setContactInfo: (email: string, phone: string) => void;
  addUserMessage: (message: string) => void;
  addSystemMessage: (message: string) => void;
  processAIMessage: (message: string) => Promise<void>;
  moveToNextStep: () => void;
  isStepComplete: (step: number) => boolean;
};

const VerificationContext = createContext<VerificationContextType | undefined>(
  undefined
);

// Provider component
export function VerificationProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(verificationReducer, initialState);

  // Helper functions
  const setFullName = (fullName: string) => {
    const { firstName, middleName, lastName } = parseFullName(fullName);
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { firstName, middleName, lastName },
    });
  };

  const setDateOfBirth = (dob: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { dateOfBirth: dob },
    });
  };

  const setSSN = (ssn: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { ssn },
    });
  };

  const setDriversLicense = (licenseNumber: string, state: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { driversLicenseNumber: licenseNumber, driversLicenseState: state },
    });
  };

  const setAddress = (street: string, city: string, state: string, zipCode: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { streetAddress: street, city, state, zipCode },
    });
  };

  const setContactInfo = (email: string, phone: string) => {
    dispatch({
      type: "UPDATE_CUSTOMER_INFO",
      payload: { emailAddress: email, phoneNumber: phone },
    });
  };

  const addUserMessage = (message: string) => {
    dispatch({
      type: "ADD_MESSAGE",
      payload: { content: message, sender: "user" },
    });
  };

  const addSystemMessage = (message: string) => {
    dispatch({
      type: "ADD_MESSAGE",
      payload: { content: message, sender: "system" },
    });
  };

  const moveToNextStep = () => {
    dispatch({
      type: "SET_STEP",
      payload: state.currentStep + 1,
    });
  };

  // Process message through AI
  // Process identity verification and OFAC checks
  const processVerification = async () => {
    try {
      dispatch({ type: "SET_SUBMITTING", payload: true });
      
      // Simulate IDV verification (in a real app, this would be an API call)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Get the SSN last digit to determine test scenario
      const ssn = state.customerInfo.ssn || "";
      const lastDigit = ssn.length > 0 ? parseInt(ssn.charAt(ssn.length - 1)) : 0;
      
      // Use the last digit of SSN to determine test results
      // Test Data Info for users:
      // - SSN ending with 1, 3, 5, 7, 9: IDV passes
      // - SSN ending with 0, 2, 4, 6, 8: IDV fails
      const idvPassed = [1, 3, 5, 7, 9].includes(lastDigit);
      
      // Update IDV status
      dispatch({
        type: "UPDATE_VERIFICATION_STATUS",
        payload: { idvPassed }
      });
      
      // If IDV fails, don't proceed further
      if (!idvPassed) {
        addSystemMessage("I'm sorry, but your identity verification has failed. This could be due to a mismatch in the information provided. Please contact our bank at 1-800-555-1234 for assistance with your application.");
        return;
      }
      
      // Add success message
      addSystemMessage("Your identity has been successfully verified. Now performing OFAC check...");
      
      // Move to next step
      dispatch({ type: "SET_STEP", payload: VERIFICATION_STEPS.OFAC_CHECK });
      
      // Simulate OFAC check (in a real app, this would be another API call)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Test Data Info for users:
      // - Driver's license numbers starting with A: OFAC passes
      // - Driver's license numbers starting with B: OFAC fails
      const dlNumber = state.customerInfo.driversLicenseNumber || "";
      const ofacPassed = dlNumber.length > 0 && !dlNumber.toUpperCase().startsWith("B");
      
      // Update OFAC status
      dispatch({
        type: "UPDATE_VERIFICATION_STATUS",
        payload: { ofacPassed }
      });
      
      // If OFAC check fails, don't proceed further
      if (!ofacPassed) {
        addSystemMessage("I'm sorry, but we cannot proceed with your account application at this time due to compliance reasons. Please visit a branch location or call 1-800-555-1234 to speak with a banking representative.");
        return;
      }
      
      // Add success message
      addSystemMessage("OFAC check completed successfully. Now opening your account...");
      
      // Move to account opening step
      dispatch({ type: "SET_STEP", payload: VERIFICATION_STEPS.ACCOUNT_OPENING });
      
      // Simulate account opening (in a real app, this would be another API call)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Generate a test account number
      const accountNumber = "9876" + Math.floor(100000 + Math.random() * 900000).toString();
      const routingNumber = "123456789";
      
      // Update account opened status
      dispatch({
        type: "UPDATE_VERIFICATION_STATUS",
        payload: { 
          accountOpened: true,
          accountNumber,
          routingNumber
        }
      });
      
      // Add completion message with account details
      addSystemMessage(`Congratulations! Your account has been successfully opened. Here are your account details:
      
Account Number: ${accountNumber}
Routing Number: ${routingNumber}
      
You will receive your debit card within 7-10 business days. In the meantime, you can access your account online by setting up your credentials at our website. Is there anything else you'd like to know about your new account?`);
      
    } catch (error) {
      console.error("Error during verification process:", error);
      addSystemMessage("I apologize, but we're experiencing technical difficulties with our verification system. Please try again later or contact our customer support at 1-800-555-1234.");
    } finally {
      dispatch({ type: "SET_SUBMITTING", payload: false });
    }
  };

  const processAIMessage = async (message: string): Promise<void> => {
    try {
      dispatch({ type: "SET_TYPING", payload: true });
      
      // If we're in verification steps, process those instead of AI
      if (state.currentStep === VERIFICATION_STEPS.IDV_VERIFICATION) {
        addSystemMessage("Processing your verification now...");
        await processVerification();
        return;
      }
      
      // Send message to AI service
      const response = await sendChatMessage(message, state.customerInfo.customerId);
      
      // Process the AI response
      dispatch({ 
        type: "PROCESS_AI_INTENT", 
        payload: response 
      });
      
    } catch (error) {
      console.error("Error processing AI message:", error);
      
      // Add fallback message that directs to identity verification
      addSystemMessage("I'll help you start the account verification process. Let's collect your information.");
      
      // If we're in the welcome step or in a loan inquiry, move to full name collection
      if (state.currentStep === VERIFICATION_STEPS.WELCOME || message.toLowerCase().includes("loan")) {
        addSystemMessage("Please provide your full legal name (first, middle if any, and last name).");
        dispatch({
          type: "SET_STEP",
          payload: VERIFICATION_STEPS.FULL_NAME
        });
      }
    } finally {
      dispatch({ type: "SET_TYPING", payload: false });
    }
  };

  const isStepComplete = (step: number): boolean => {
    const { customerInfo, verificationStatus } = state;
    
    switch (step) {
      case VERIFICATION_STEPS.WELCOME:
        // Welcome step is always considered complete to allow progression
        return true;
      case VERIFICATION_STEPS.FULL_NAME:
        return !!customerInfo.firstName && !!customerInfo.lastName;
      case VERIFICATION_STEPS.DATE_OF_BIRTH:
        return !!customerInfo.dateOfBirth;
      case VERIFICATION_STEPS.SSN:
        return !!customerInfo.ssn;
      case VERIFICATION_STEPS.DRIVERS_LICENSE:
        return !!customerInfo.driversLicenseNumber && !!customerInfo.driversLicenseState;
      case VERIFICATION_STEPS.ADDRESS:
        return !!customerInfo.streetAddress && !!customerInfo.city && 
               !!customerInfo.state && !!customerInfo.zipCode;
      case VERIFICATION_STEPS.CONTACT_INFO:
        return !!customerInfo.emailAddress && !!customerInfo.phoneNumber;
      case VERIFICATION_STEPS.IDV_VERIFICATION:
        return verificationStatus.idvPassed === true;
      case VERIFICATION_STEPS.OFAC_CHECK:
        return verificationStatus.ofacPassed === true;
      case VERIFICATION_STEPS.ACCOUNT_OPENING:
        return verificationStatus.accountOpened === true;
      default:
        return false;
    }
  };

  return (
    <VerificationContext.Provider
      value={{
        state,
        dispatch,
        setFullName,
        setDateOfBirth,
        setSSN,
        setDriversLicense,
        setAddress,
        setContactInfo,
        addUserMessage,
        addSystemMessage,
        processAIMessage,
        moveToNextStep,
        isStepComplete,
      }}
    >
      {children}
    </VerificationContext.Provider>
  );
}

// Custom hook for using the verification context
export function useVerification() {
  const context = useContext(VerificationContext);
  if (context === undefined) {
    throw new Error(
      "useVerification must be used within a VerificationProvider"
    );
  }
  return context;
}
