import React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { contactInfoSchema, ContactInfoFormData } from "@/lib/validation";

interface ContactInfoFormProps {
  onSubmit: (data: ContactInfoFormData) => void;
}

export function ContactInfoForm({ onSubmit }: ContactInfoFormProps) {
  // Create a completely new form instance isolated from other forms
  const form = useForm<ContactInfoFormData>({
    resolver: zodResolver(contactInfoSchema),
    defaultValues: {
      emailAddress: "",
      phoneNumber: "",
    },
  });

  const handleSubmit = (data: ContactInfoFormData) => {
    console.log("Contact info form submitted:", data);
    // Pass the validated data to the parent component
    onSubmit(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-2">
        <FormField
          control={form.control}
          name="emailAddress"
          render={({ field }) => (
            <FormItem>
              <FormControl>
                <Input 
                  placeholder="Email Address" 
                  type="email"
                  value={field.value} 
                  onChange={(e) => {
                    field.onChange(e);
                    console.log("Email field changed:", e.target.value);
                  }}
                  className="w-full"
                />
              </FormControl>
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="phoneNumber"
          render={({ field }) => (
            <FormItem>
              <FormControl>
                <Input 
                  placeholder="Phone Number" 
                  value={field.value}
                  onChange={(e) => {
                    field.onChange(e);
                    console.log("Phone field changed:", e.target.value);
                  }}
                  className="w-full"
                />
              </FormControl>
            </FormItem>
          )}
        />
        
        <div className="flex justify-end">
          <Button type="submit" size="sm">
            Submit
          </Button>
        </div>
      </form>
    </Form>
  );
}