import React from "react";
import { Form, FormControl, FormField, FormItem } from "./ui/form";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { dateOfBirthSchema, DateOfBirthFormData } from "@/lib/validation";

interface DateOfBirthFormProps {
  onSubmit: (data: DateOfBirthFormData) => void;
}

export function DateOfBirthForm({ onSubmit }: DateOfBirthFormProps) {
  const form = useForm<DateOfBirthFormData>({
    resolver: zodResolver(dateOfBirthSchema),
    defaultValues: {
      dateOfBirth: "",
    },
  });

  const handleSubmit = (data: DateOfBirthFormData) => {
    onSubmit(data);
    form.reset();
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-2">
        <FormField
          control={form.control}
          name="dateOfBirth"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormControl>
                <div className="space-y-2">
                  <Input
                    placeholder="MM/DD/YYYY"
                    {...field}
                    className="w-full"
                  />
                  
                  {/* Example date buttons for easier input */}
                  <div className="flex flex-wrap gap-1">
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        const date = "01/15/1990";
                        field.onChange(date);
                        console.log("Selected example date:", date);
                      }}
                      className="text-xs py-0"
                    >
                      01/15/1990
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        const date = "05/20/1985";
                        field.onChange(date);
                        console.log("Selected example date:", date);
                      }}
                      className="text-xs py-0"
                    >
                      05/20/1985
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        const date = "12/31/1980";
                        field.onChange(date);
                        console.log("Selected example date:", date);
                      }}
                      className="text-xs py-0"
                    >
                      12/31/1980
                    </Button>
                  </div>
                </div>
              </FormControl>
              {form.formState.errors.dateOfBirth && (
                <div className="text-xs text-red-500 mt-1">
                  {form.formState.errors.dateOfBirth.message}
                </div>
              )}
              <div className="text-xs text-neutral-500 mt-1">
                Please enter your date of birth in MM/DD/YYYY format
              </div>
            </FormItem>
          )}
        />
        <div className="flex justify-end">
          <Button type="submit" size="sm">
            Submit
          </Button>
        </div>
      </form>
    </Form>
  );
}