import React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { driversLicenseSchema, DriversLicenseFormData } from "@/lib/validation";

interface DriversLicenseFormProps {
  onSubmit: (data: DriversLicenseFormData) => void;
}

export function DriversLicenseForm({ onSubmit }: DriversLicenseFormProps) {
  // Create a new form instance specifically for this component
  const form = useForm<DriversLicenseFormData>({
    resolver: zodResolver(driversLicenseSchema),
    defaultValues: {
      driversLicenseNumber: "",
      driversLicenseState: "",
    },
  });

  const handleSubmit = (data: DriversLicenseFormData) => {
    console.log("License form submitted:", data);
    // Pass the validated data to the parent component
    onSubmit(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-2">
        <FormField
          control={form.control}
          name="driversLicenseNumber"
          render={({ field }) => (
            <FormItem>
              <FormControl>
                <Input 
                  placeholder="Driver's License Number" 
                  value={field.value} 
                  onChange={(e) => {
                    field.onChange(e);
                    console.log("Driver's license field changed:", e.target.value);
                  }} 
                  className="w-full"
                />
              </FormControl>
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="driversLicenseState"
          render={({ field }) => (
            <FormItem>
              <FormControl>
                <Input 
                  placeholder="State (2-letter code, e.g., CA)" 
                  value={field.value} 
                  onChange={(e) => field.onChange(e)} 
                  className="w-full"
                  maxLength={2}
                />
              </FormControl>
            </FormItem>
          )}
        />
        
        <div className="flex justify-end">
          <Button type="submit" size="sm">
            Submit
          </Button>
        </div>
      </form>
    </Form>
  );
}