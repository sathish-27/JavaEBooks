import React from "react";
import { BankingCopilot } from "@/components/BankingCopilot";

export default function Home() {
  return <BankingCopilot />;
}
