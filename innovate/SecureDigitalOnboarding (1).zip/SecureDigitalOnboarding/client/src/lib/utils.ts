import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDateString(dateString: string): string {
  // Check if the date matches MM/DD/YYYY format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/;
  if (!dateRegex.test(dateString)) {
    return dateString;
  }

  // Parse the date parts
  const [month, day, year] = dateString.split('/').map(part => parseInt(part, 10));
  
  // Create a Date object
  const date = new Date(year, month - 1, day);
  
  // Format the date with a more readable format
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

export function formatSSN(ssn: string): string {
  // Check if the SSN is already formatted or has the right length
  if (/^\d{3}-\d{2}-\d{4}$/.test(ssn)) {
    return ssn;
  }
  
  // If it's just 9 digits without dashes, format it
  if (/^\d{9}$/.test(ssn)) {
    return `${ssn.substring(0, 3)}-${ssn.substring(3, 5)}-${ssn.substring(5, 9)}`;
  }
  
  // Otherwise, return the original string
  return ssn;
}

export function parseFullName(fullName: string): { firstName: string; middleName?: string; lastName: string } {
  // Split the full name into parts
  const nameParts = fullName.trim().split(/\s+/);
  
  // If there's only one part, treat it as the first name
  if (nameParts.length === 1) {
    return {
      firstName: nameParts[0],
      lastName: ""
    };
  }
  
  // If there are two parts, treat them as first and last name
  if (nameParts.length === 2) {
    return {
      firstName: nameParts[0],
      lastName: nameParts[1]
    };
  }
  
  // If there are more than two parts, treat the first part as the first name,
  // the last part as the last name, and everything in between as the middle name
  return {
    firstName: nameParts[0],
    middleName: nameParts.slice(1, -1).join(" "),
    lastName: nameParts[nameParts.length - 1]
  };
}

export function maskSSN(ssn: string): string {
  // Check if the SSN is formatted correctly
  const ssnRegex = /^\d{3}-\d{2}-\d{4}$/;
  if (!ssnRegex.test(ssn)) {
    // Try to format it if it's just 9 digits
    if (/^\d{9}$/.test(ssn)) {
      ssn = `${ssn.substring(0, 3)}-${ssn.substring(3, 5)}-${ssn.substring(5, 9)}`;
    } else {
      return ssn; // Return the original if it doesn't match the format
    }
  }
  
  // Mask the SSN to show only the last 4 digits
  return `XXX-XX-${ssn.substring(7, 11)}`;
}

export function getVerificationProgressPercentage(
  steps: { completed: boolean }[]
): number {
  const completedSteps = steps.filter(step => step.completed).length;
  return Math.round((completedSteps / steps.length) * 100);
}
