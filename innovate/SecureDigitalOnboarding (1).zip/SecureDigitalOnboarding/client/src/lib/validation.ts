import { z } from "zod";

// Validation schemas for each step of the verification process
export const fullNameSchema = z.object({
  fullName: z
    .string()
    .min(2, "Please enter your full legal name")
    .max(100, "Name is too long")
    .regex(/^[a-zA-Z\s-']+$/, "Please use only letters, spaces, hyphens, and apostrophes")
});

export const dateOfBirthSchema = z.object({
  dateOfBirth: z
    .string()
    .min(1, "Date of birth is required")
    .refine(
      (dob) => {
        try {
          // Check if the format is MM/DD/YYYY
          const isFormatValid = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/.test(dob);
          if (!isFormatValid) {
            console.log("DOB validation failed: invalid format");
            return false;
          }
          
          const [month, day, year] = dob.split('/').map(Number);
          
          // Basic format validation
          if (isNaN(month) || isNaN(day) || isNaN(year)) {
            console.log("DOB validation failed: invalid number format");
            return false;
          }
          
          if (month < 1 || month > 12 || day < 1 || day > 31 || year < 1900 || year > 2020) {
            console.log("DOB validation failed: out of range values");
            return false;
          }
          
          // Create date object and validate coherence
          const date = new Date(year, month - 1, day);
          const today = new Date();
          
          // The date must be valid (e.g., not Feb 30)
          const isValidDate = date.getMonth() === month - 1 && 
                             date.getDate() === day && 
                             date.getFullYear() === year;
          
          if (!isValidDate) {
            console.log("DOB validation failed: incoherent date");
            return false;
          }
          
          // User must be at least 18 years old
          const is18OrOlder = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate()) >= date;
          
          if (!is18OrOlder) {
            console.log("DOB validation failed: under 18");
            return false;
          }
          
          console.log("DOB validation passed");
          return true;
        } catch (error) {
          console.error("DOB validation error:", error);
          return false;
        }
      },
      {
        message: "You must be at least 18 years old and enter a valid date in MM/DD/YYYY format"
      }
    )
});

export const ssnSchema = z.object({
  ssn: z
    .string()
    .regex(
      /^\d{3}-\d{2}-\d{4}$/,
      "Please enter a valid SSN in XXX-XX-XXXX format"
    )
    .or(
      z
        .string()
        .regex(/^\d{9}$/, "Please enter a 9-digit SSN")
        .transform((val) => `${val.slice(0, 3)}-${val.slice(3, 5)}-${val.slice(5)}`)
    )
});

export const driversLicenseSchema = z.object({
  driversLicenseNumber: z
    .string()
    .min(1, "Driver's license number is required")
    .max(20, "License number is too long"),
  driversLicenseState: z
    .string()
    .length(2, "Please enter a valid 2-letter state code")
    .regex(/^[A-Z]{2}$/, "Please use uppercase letters for state code")
});

export const addressSchema = z.object({
  streetAddress: z
    .string()
    .min(5, "Please enter your complete street address")
    .max(100, "Address is too long"),
  city: z
    .string()
    .min(2, "City name is required")
    .max(50, "City name is too long")
    .regex(/^[a-zA-Z\s-'.]+$/, "Please use only letters, spaces, hyphens, apostrophes, and periods"),
  state: z
    .string()
    .length(2, "Please enter a valid 2-letter state code")
    .regex(/^[A-Z]{2}$/, "Please use uppercase letters for state code"),
  zipCode: z
    .string()
    .regex(/^\d{5}(-\d{4})?$/, "Please enter a valid ZIP code (XXXXX or XXXXX-XXXX)")
});

export const contactInfoSchema = z.object({
  emailAddress: z
    .string()
    .email("Please enter a valid email address"),
  phoneNumber: z
    .string()
    .regex(/^\d{3}-\d{3}-\d{4}$/, "Please enter a valid phone number in XXX-XXX-XXXX format")
    .or(
      z
        .string()
        .regex(/^\d{10}$/, "Please enter a 10-digit phone number")
        .transform((val) => `${val.slice(0, 3)}-${val.slice(3, 6)}-${val.slice(6)}`)
    )
});

// Combine all schemas for a complete verification form
export const completeVerificationSchema = z.object({
  ...fullNameSchema.shape,
  ...dateOfBirthSchema.shape,
  ...ssnSchema.shape,
  ...driversLicenseSchema.shape,
  ...addressSchema.shape,
  ...contactInfoSchema.shape,
});

export type FullNameFormData = z.infer<typeof fullNameSchema>;
export type DateOfBirthFormData = z.infer<typeof dateOfBirthSchema>;
export type SSNFormData = z.infer<typeof ssnSchema>;
export type DriversLicenseFormData = z.infer<typeof driversLicenseSchema>;
export type AddressFormData = z.infer<typeof addressSchema>;
export type ContactInfoFormData = z.infer<typeof contactInfoSchema>;
export type CompleteVerificationFormData = z.infer<typeof completeVerificationSchema>;
