import { apiRequest, getQueryFn } from "./queryClient";
import { ChatMessage } from "@/context/VerificationContext";

export type AIResponse = {
  message: string;
  intent?: "ACCOUNT_OPENING" | "LOAN_APPLICATION" | "GENERAL_INQUIRY" | "UNKNOWN";
  loanType?: "MORTGAGE" | "AUTO" | "PERSONAL" | "BUSINESS" | "UNKNOWN";
  actionRequired?: boolean;
  requiredInfo?: string[];
  recommendedNextStep?: string;
};

/**
 * Sends a user message to the AI chat service
 * @param message The user's message to process
 * @param customerId Optional customer ID to associate with the chat
 * @returns The AI response
 */
export async function sendChatMessage(message: string, customerId?: number): Promise<AIResponse> {
  return apiRequest<AIResponse>({
    url: "/api/chat",
    method: "POST",
    body: { message, customerId },
    on401: "throw",
  });
}

/**
 * Resets the chat conversation with the AI
 * @returns Success message
 */
export async function resetChatConversation(): Promise<{ message: string }> {
  return apiRequest<{ message: string }>({
    url: "/api/chat/reset",
    method: "GET",
    on401: "throw",
  });
}

/**
 * Formats an AIResponse into a chat message
 * @param response The AI response from the server
 * @returns A formatted chat message
 */
export function formatAIResponseToChatMessage(response: AIResponse): ChatMessage {
  return {
    id: crypto.randomUUID(),
    content: response.message,
    sender: "system",
    timestamp: new Date(),
  };
}