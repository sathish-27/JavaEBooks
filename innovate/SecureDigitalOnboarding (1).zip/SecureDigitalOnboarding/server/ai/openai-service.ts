import OpenAI from "openai";

// Types
export type AIChatMessage = {
  role: "user" | "assistant" | "system";
  content: string;
};

export type Intent = "ACCOUNT_OPENING" | "LOAN_APPLICATION" | "GENERAL_INQUIRY" | "UNKNOWN";

export type LoanType = "MORTGAGE" | "AUTO" | "PERSONAL" | "BUSINESS" | "UNKNOWN";

export type AIResponse = {
  message: string;
  intent?: Intent;
  loanType?: LoanType;
  actionRequired?: boolean;
  requiredInfo?: string[];
  recommendedNextStep?: string;
};

// System prompts
const SYSTEM_PROMPT = `You are an AI banking assistant. Your primary role is to help users with account opening and loan applications.
You should identify user intent and guide them through the appropriate workflow. Maintain a professional, helpful tone.

Key workflows:
1. Account Opening: Collect personal details (name, DOB, SSN, address, etc.) and run IDV and OFAC checks
2. Loan Application: Identify loan type (mortgage, auto, personal, business), collect personal details, loan amount, and conduct IDV, OFAC, and credit assessment

Your capabilities:
- Analyze user intent
- Follow appropriate workflows
- Request necessary information
- Generate loan underwriting documents when appropriate

Always respond with clear, concise information. If you need specific information to proceed, explicitly ask for it.`;

// Service class
export class OpenAIService {
  private client: OpenAI | null = null;
  private conversationHistory: AIChatMessage[] = [];
  private model: string = "gpt-4o"; // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user

  constructor() {
    // Initialize with system prompt
    this.conversationHistory = [
      { role: "system", content: SYSTEM_PROMPT }
    ];

    // Initialize OpenAI client if API key is available
    const apiKey = process.env.OPENAI_API_KEY || process.env.AZURE_OPENAI_API_KEY;
    
    if (apiKey) {
      try {
        // If using Azure, configure the client accordingly
        if (process.env.AZURE_OPENAI_ENDPOINT) {
          this.client = new OpenAI({
            apiKey: apiKey,
            baseURL: process.env.AZURE_OPENAI_ENDPOINT,
            defaultQuery: { "api-version": "2023-05-15" },
            defaultHeaders: { "api-key": apiKey }
          });
          console.log("Azure OpenAI client initialized successfully");
        } else {
          // Standard OpenAI client
          this.client = new OpenAI({ apiKey });
          console.log("OpenAI client initialized successfully");
        }
      } catch (error) {
        console.error("Failed to initialize OpenAI client:", error);
      }
    } else {
      console.warn("OpenAI API key missing. AI features will be limited.");
    }
  }

  // Add a user message to the conversation
  public async processUserMessage(userMessage: string): Promise<AIResponse> {
    // Add user message to history
    this.conversationHistory.push({ role: "user", content: userMessage });

    // If client is not initialized, return a fallback response
    if (!this.client) {
      return this.getFallbackResponse(userMessage);
    }

    try {
      // Get completion from OpenAI
      const response = await this.client.chat.completions.create({
        model: this.model,
        messages: this.conversationHistory.map(msg => ({
          role: msg.role,
          content: msg.content
        }))
      });

      // Get the assistant's message
      const assistantMessage = response.choices[0]?.message?.content || "I'm sorry, I couldn't process that request.";
      
      // Add assistant response to history
      this.conversationHistory.push({ role: "assistant", content: assistantMessage });

      // Analyze the intent and extract structured information
      return this.analyzeResponse(userMessage, assistantMessage);
    } catch (error) {
      console.error("Error getting completion from OpenAI:", error);
      
      // Handle rate limit errors
      if (error && typeof error === 'object' && 'status' in error && error.status === 429) {
        // Always use ACCOUNT_OPENING intent for rate limit errors to ensure consistent flow
        return {
          message: "I'll help you start the identity verification process for your account. This will be needed whether you're opening an account or applying for a loan.",
          intent: "ACCOUNT_OPENING",
          actionRequired: true,
          requiredInfo: ["fullName", "dateOfBirth", "ssn", "address"],
          recommendedNextStep: "Begin identity verification process"
        };
      }
      
      return this.getFallbackResponse(userMessage);
    }
  }

  // Process user intent from message
  private analyzeResponse(userMessage: string, assistantMessage: string): AIResponse {
    // Default response
    const response: AIResponse = {
      message: assistantMessage,
      intent: "UNKNOWN",
      actionRequired: false
    };

    // Determine intent from conversation
    if (this.containsAccountOpeningKeywords(userMessage)) {
      response.intent = "ACCOUNT_OPENING";
      response.actionRequired = true;
      response.requiredInfo = ["fullName", "dateOfBirth", "ssn", "address"];
      response.recommendedNextStep = "Collect user personal information";
    } else if (this.containsLoanKeywords(userMessage)) {
      response.intent = "LOAN_APPLICATION";
      response.loanType = this.determineLoanType(userMessage);
      response.actionRequired = true;
      response.requiredInfo = ["fullName", "dateOfBirth", "ssn", "address", "income", "loanAmount", "loanPurpose"];
      response.recommendedNextStep = "Collect user personal and loan information";
    } else {
      response.intent = "GENERAL_INQUIRY";
      response.actionRequired = false;
    }

    return response;
  }

  // Helper methods for intent analysis
  private containsAccountOpeningKeywords(text: string): boolean {
    const keywords = ["open account", "new account", "create account", "checking account", "savings account"];
    return keywords.some(keyword => text.toLowerCase().includes(keyword));
  }

  private containsLoanKeywords(text: string): boolean {
    const keywords = ["loan", "mortgage", "financing", "borrow money", "car loan", "auto loan", "personal loan", "business loan"];
    return keywords.some(keyword => text.toLowerCase().includes(keyword));
  }

  private determineLoanType(text: string): LoanType {
    const text_lower = text.toLowerCase();
    
    if (text_lower.includes("mortgage") || text_lower.includes("home loan") || text_lower.includes("house loan")) {
      return "MORTGAGE";
    } else if (text_lower.includes("auto loan") || text_lower.includes("car loan") || text_lower.includes("vehicle")) {
      return "AUTO";
    } else if (text_lower.includes("personal loan")) {
      return "PERSONAL";
    } else if (text_lower.includes("business loan") || text_lower.includes("commercial")) {
      return "BUSINESS";
    }
    
    return "UNKNOWN";
  }

  // Fallback when API is not available
  private getFallbackResponse(userMessage: string): AIResponse {
    let message = "Let me help you get started with our banking services.";
    let intent: Intent = "ACCOUNT_OPENING"; // Default to account opening to keep the flow moving
    let loanType: LoanType | undefined = undefined;
    
    // Basic intent detection 
    if (this.containsAccountOpeningKeywords(userMessage)) {
      message = "I'll help you open a new account. Let's start with collecting your personal information.";
      intent = "ACCOUNT_OPENING";
    } else if (this.containsLoanKeywords(userMessage)) {
      message = "I understand you're interested in a loan. First, we need to verify your identity. Let's start with your personal information.";
      intent = "LOAN_APPLICATION";
      loanType = this.determineLoanType(userMessage);
    }
    
    return {
      message,
      intent,
      loanType,
      actionRequired: true,
      requiredInfo: ["fullName", "dateOfBirth", "ssn", "address"],
      recommendedNextStep: "Begin identity verification process"
    };
  }
  
  // Clear conversation history (except system prompt)
  public clearConversation(): void {
    this.conversationHistory = [this.conversationHistory[0]];
  }
}

// Export singleton instance
export const aiService = new OpenAIService();