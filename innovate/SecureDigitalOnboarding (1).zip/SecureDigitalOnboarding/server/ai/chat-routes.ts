import { Router, Request, Response } from "express";
import { aiService } from "./openai-service";
import { z } from "zod";

const router = Router();

// Schema for chat message request
const chatMessageSchema = z.object({
  message: z.string().min(1),
  customerId: z.number().optional(),
});

// POST endpoint to process chat messages
router.post("/api/chat", async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validation = chatMessageSchema.safeParse(req.body);
    
    if (!validation.success) {
      return res.status(400).json({
        error: "Invalid request body",
        details: validation.error.format(),
      });
    }
    
    const { message, customerId } = validation.data;
    
    // Process the message with our AI service
    const aiResponse = await aiService.processUserMessage(message);
    
    // Return the AI response
    return res.status(200).json(aiResponse);
  } catch (error) {
    console.error("Error processing chat message:", error);
    return res.status(500).json({
      error: "Failed to process chat message",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

// GET endpoint to reset conversation
router.get("/api/chat/reset", (_req: Request, res: Response) => {
  try {
    aiService.clearConversation();
    return res.status(200).json({ message: "Conversation reset successfully" });
  } catch (error) {
    console.error("Error resetting conversation:", error);
    return res.status(500).json({
      error: "Failed to reset conversation",
      message: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

export default router;