import os
import json
import logging
import requests
import re
from datetime import datetime
from config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_DEPLOYMENT_NAME
)

logger = logging.getLogger(__name__)

def analyze_conversation_state(conversation_history):
    """
    Analyze the conversation history to determine the current state.
    
    Args:
        conversation_history (list): Previous conversation messages
        
    Returns:
        dict: A dictionary with flags for different conversation states
    """
    if not conversation_history:
        return {'collect_name': True}
    
    # Initialize state object
    state = {}
    
    # Get bot messages from conversation history
    bot_messages = [msg.get('text', '') for msg in conversation_history if msg.get('is_bot', False)]
    user_messages = [msg.get('text', '') for msg in conversation_history if not msg.get('is_bot', False)]
    
    # Special check for multiple "no" responses in a row - this indicates we should reset
    if len(user_messages) >= 2:
        no_responses = 0
        for i in range(1, min(4, len(user_messages) + 1)):
            if user_messages[-i].lower().strip() in ['no', 'nope', 'nothing']:
                no_responses += 1
                
        # If user has said "no" multiple times, we should reset entirely
        if no_responses >= 2:
            logger.debug(f"Detected {no_responses} consecutive 'no' responses - forcing a reset")
            return {'reset_conversation': True}
    
    # SPECIAL CASE: Check for completion keywords in the recent bot messages
    # This prevents looping back to initial state after account completion
    account_completed_phrases = [
        "great news", "both your identity verification", 
        "account has been created", "account number will be sent",
        "passed successfully"
    ]
    
    # If we've recently sent an account completion message and user has sent short "yes" type responses
    recent_bot_messages = bot_messages[-3:] if len(bot_messages) >= 3 else bot_messages
    if any(phrase in " ".join(recent_bot_messages).lower() for phrase in account_completed_phrases):
        # Check if the most recent user responses were short (likely "yes", "no" type answers)
        recent_user_msgs = user_messages[-2:] if len(user_messages) >= 2 else user_messages
        if all(len(msg.split()) <= 2 for msg in recent_user_msgs):
            logger.debug("SAFETY: Account completion detected with short user responses. Preventing DOB loop.")
            return {'account_completed': True}
    
    # Check for name collection
    name_patterns = [
        "please tell me your full name",
        "could you please tell me your full name",
        "please provide your full name",
        "what is your full name",
        "may i have your name"
    ]
    if any(any(pattern.lower() in msg.lower() for pattern in name_patterns) for msg in bot_messages):
        # If we've already asked for a name, check if user has provided it
        if len(user_messages) > 0 and user_messages[-1]:
            state['collect_dob'] = True
        else:
            state['collect_name'] = True
    
    # Determine the current stage based on the most recent bot messages
    bot_messages_reversed = list(reversed(bot_messages))  # Most recent first
    user_messages_reversed = list(reversed(user_messages))  # Most recent first
    
    # Get the most recent user message for validation
    last_user_message = user_messages[-1] if user_messages else ""
    
    # This will hold our detected stage
    current_stage = None
    
    # Function to search for patterns in recent bot messages
    def find_pattern_in_recent_messages(patterns, num_messages=2):
        for i, msg in enumerate(bot_messages_reversed[:num_messages]):
            if any(pattern.lower() in msg.lower() for pattern in patterns):
                return True
        return False
    
    # Define patterns for each stage
    name_patterns = ["please tell me your full name", "your full name", "tell me your name"]
    dob_patterns = ["date of birth", "dob", "yyyy-mm-dd", "birthdate"]
    address_patterns = ["residential address", "your address", "street, city", "where you live"]
    email_patterns = ["email address", "your email", "contact you via email"]
    phone_patterns = ["phone number", "contact number", "telephone", "call you"]
    id_verification_patterns = ["upload an id", "document verification", "identity verification", "upload a document"]
    account_type_patterns = ["type of account", "which account", "select an account", "basic checking", "premium checking"]
    running_verification_patterns = ["identity verification (idv)", "compliance check", "required regulatory checks", "ofac screening", "important checks"]
    account_completed_patterns = ["great news", "account has been created", "successfully", "account number will be sent", "passed successfully"]
    
    # Check for progress through the workflow stages - ordering from most advanced to least advanced
    if find_pattern_in_recent_messages(account_completed_patterns):
        current_stage = 'account_completed'
    elif find_pattern_in_recent_messages(running_verification_patterns):
        current_stage = 'running_verifications'
    elif find_pattern_in_recent_messages(account_type_patterns):
        current_stage = 'select_account_type'
    elif find_pattern_in_recent_messages(id_verification_patterns):
        current_stage = 'id_verification'
    elif find_pattern_in_recent_messages(phone_patterns):
        current_stage = 'collect_phone'
    elif find_pattern_in_recent_messages(email_patterns):
        current_stage = 'collect_email'
    elif find_pattern_in_recent_messages(address_patterns):
        current_stage = 'collect_address'
    elif find_pattern_in_recent_messages(dob_patterns):
        current_stage = 'collect_dob'
    elif find_pattern_in_recent_messages(name_patterns) or not bot_messages:
        current_stage = 'collect_name'
    
    # Log the current stage detection
    logger.debug(f"Detected current stage: {current_stage}")
    
    # Set state based on current stage and input validation
    if current_stage == 'collect_name':
        if len(last_user_message.split()) <= 3 and len(last_user_message) > 0:
            # User provided name, move to next stage
            state['collect_dob'] = True
        else:
            state['collect_name'] = True
            
    elif current_stage == 'collect_dob':
        if has_date_format(last_user_message):
            # Valid date format provided, move to next stage
            logger.debug(f"Date format detected in: '{last_user_message}'")
            state['collect_address'] = True
            # Remove collect_dob flag to prevent loops
            state.pop('collect_dob', None)
        else:
            state['collect_dob'] = True
            
    elif current_stage == 'collect_address':
        # Clear any leftover collect_dob flag to avoid state conflicts
        if 'collect_dob' in state:
            del state['collect_dob']
            
        # Always move to email collection if any address-like input is provided
        # This prevents the address loop issue
        state['collect_email'] = True
            
    elif current_stage == 'collect_email':
        # Clear any leftover collect_dob flag to avoid state conflicts
        if 'collect_dob' in state:
            del state['collect_dob']
            
        if '@' in last_user_message and '.' in last_user_message:
            # Email provided, move to next stage
            state['collect_phone'] = True
        else:
            state['collect_email'] = True
            
    elif current_stage == 'collect_phone':
        # First, clear any leftover conflicting flags
        if 'collect_dob' in state:
            del state['collect_dob']
            
        if any(c.isdigit() for c in last_user_message) and len([c for c in last_user_message if c.isdigit()]) >= 7:
            # Phone number provided, move to next stage
            state = {'id_verification': True}  # Reset the state completely to just this flag
        else:
            state = {'collect_phone': True}  # Reset the state completely to just this flag
            
    elif current_stage == 'id_verification':
        # Clear any leftover flags completely to avoid any state conflicts
        state = {}  # Reset state to avoid any loops
        
        if any(keyword in last_user_message.lower() for keyword in ["yes", "upload", "ok", "document", "verification"]):
            state['document_uploaded'] = True
        elif any(keyword in last_user_message.lower() for keyword in ["no", "skip", "without", "later"]):
            state['select_account_type'] = True
        else:
            state['id_verification'] = True
            
    elif current_stage == 'select_account_type':
        # Reset state completely to prevent any loops back to DOB
        state = {}
        
        if any(account_type in last_user_message.lower() for account_type in ["basic", "premium", "essential", "checking", "savings"]):
            state['running_verifications'] = True
        else:
            state['select_account_type'] = True
            
    elif current_stage == 'running_verifications':
        # Reset state completely to ensure we don't loop
        state = {}
        state['account_completed'] = True
        
    elif current_stage == 'account_completed':
        # Account is completed - don't do anything else, just maintain the completed state
        state = {'account_completed': True}
    
    # Check for document upload success
    if any("i've successfully extracted" in msg.lower() for msg in bot_messages):
        state['document_uploaded'] = True
        
    # The rest of the state is determined by our above stage detection and validation logic
    # We've removed duplicate checks to prevent confusion and contradictory states
    
    # This section covers loan-related states that we aren't modifying
    
    # FINAL SAFETY CHECK - if we've progressed beyond DOB collection but still have that flag, remove it 
    # This prevents the loop back to DOB once we've moved past that stage
    key_progression = ['collect_dob', 'collect_address', 'collect_email', 'collect_phone', 
                       'id_verification', 'document_uploaded', 'select_account_type', 'running_verifications', 'account_completed']
    
    for i, key in enumerate(key_progression[1:], 1):
        if key in state and 'collect_dob' in state:
            # If we're at a later stage but also have collect_dob flag, remove the DOB flag
            logger.debug(f"SAFETY CHECK: Removing conflicting DOB flag as we're at stage: {key}")
            state.pop('collect_dob', None)
            
    # ENSURE ONLY ONE STATE FLAG AT A TIME
    # This is a final safety check - if we have more than one workflow state, keep only the most advanced one
    if len(state) > 1 and any(k in state for k in key_progression):
        # Find the most advanced stage we've reached
        most_advanced = -1
        for i, key in enumerate(key_progression):
            if key in state:
                most_advanced = max(most_advanced, i)
        
        if most_advanced >= 0:
            # Keep only the most advanced stage
            advanced_key = key_progression[most_advanced]
            logger.debug(f"SAFETY CHECK: Multiple states detected, keeping only: {advanced_key}")
            state = {advanced_key: True}
    
    return state

def has_date_format(text):
    """
    Check if the text contains a valid date format.
    
    Args:
        text (str): Text to check for date format
        
    Returns:
        bool: True if a date format is found, False otherwise
    """
    text = text.strip()
    logger.debug(f"Checking for date format in: '{text}'")
    
    # Special case for phone numbers to avoid confusion with dates
    digits = ''.join(re.findall(r'\d', text))
    if len(digits) >= 10 and (not '-' in text) and (not '/' in text):
        # If it has 10 or more consecutive digits with no separators, it's likely a phone number
        logger.debug(f"Likely a phone number with {len(digits)} digits, not a date")
        return False
        
    # Check for any numbers that might represent a date
    if re.search(r'\d', text):
        # If there are at least 6 digits and at most 9 digits, it might be a date
        if 6 <= len(digits) <= 9:
            logger.debug(f"Found date-like pattern with {len(digits)} digits")
            return True
    
    # Check for YYYY-MM-DD format
    if re.search(r'\d{4}-\d{1,2}-\d{1,2}', text):
        logger.debug("Found YYYY-MM-DD format")
        return True
    
    # Check for MM/DD/YYYY format
    if re.search(r'\d{1,2}/\d{1,2}/\d{4}', text):
        logger.debug("Found MM/DD/YYYY format")
        return True
    
    # Check for any date-like separators
    if '-' in text or '/' in text or '.' in text:
        parts = re.split(r'[-/.]', text)
        if len(parts) == 3:
            # If there are 3 parts and they all contain digits, it's likely a date
            if all(re.search(r'\d', part) for part in parts):
                logger.debug("Found date-like parts with separators")
                return True
    
    # Check for written date format (e.g., "January 15, 1980")
    months = ['january', 'february', 'march', 'april', 'may', 'june', 
              'july', 'august', 'september', 'october', 'november', 'december']
    text_lower = text.lower()
    
    for month in months:
        if month in text_lower and re.search(r'\d{1,2}(st|nd|rd|th)?[, ]+\d{4}', text_lower):
            logger.debug("Found written date format")
            return True
    
    # Handle special formatted cases like "199-01-01"
    if re.search(r'\d{3}-\d{1,2}-\d{1,2}', text):
        logger.debug("Found special 3-digit year format")
        return True
    
    logger.debug("No date format detected")
    return False

def process_user_message(message, conversation_history=None, workflow=None):
    """
    Process the user message using Azure OpenAI and return the response.
    
    Args:
        message (str): User's message
        conversation_history (list): Previous conversation messages
        workflow (str): Current workflow context (account, loan, products)
        
    Returns:
        str: AI response
    """
    if not conversation_history:
        conversation_history = []
    
    try:
        # In a real application, we would use the Azure OpenAI SDK
        # For this mock implementation, we'll simulate the response
        
        # Check if we're using real Azure OpenAI or mocking the response
        if AZURE_OPENAI_API_KEY != "mock-api-key":
            return call_azure_openai(message, conversation_history, workflow)
        else:
            return generate_mock_response(message, conversation_history, workflow)
    
    except Exception as e:
        logger.error(f"Error processing message with OpenAI: {str(e)}")
        return "I'm sorry, I encountered an error processing your request. Please try again later."

def call_azure_openai(message, conversation_history, workflow=None):
    """
    Call the Azure OpenAI service to process the user message.
    
    Args:
        message (str): User's message
        conversation_history (list): Previous conversation messages
        workflow (str): Current workflow context (account, loan, products)
        
    Returns:
        str: AI response
    """
    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_OPENAI_API_KEY
    }
    
    # Format the conversation history for the API
    messages = [{"role": "system", "content": "You are a helpful banking assistant that helps users onboard to banking services, apply for loans, and answer questions about bank products."}]
    
    # Add conversation history
    for msg in conversation_history:
        role = "assistant" if msg.get("is_bot", False) else "user"
        messages.append({"role": role, "content": msg.get("text", "")})
    
    # Add the new message
    messages.append({"role": "user", "content": message})
    
    # Prepare the request
    request_data = {
        "messages": messages,
        "max_tokens": 100,
        "temperature": 0.7,
        "frequency_penalty": 0,
        "presence_penalty": 0,
        "top_p": 0.95,
        "stop": None
    }
    
    # Construct the API URL
    api_url = f"{AZURE_OPENAI_ENDPOINT}/openai/deployments/{AZURE_OPENAI_DEPLOYMENT_NAME}/chat/completions?api-version={AZURE_OPENAI_API_VERSION}"
    
    # Call the API
    response = requests.post(api_url, headers=headers, json=request_data)
    
    if response.status_code == 200:
        response_data = response.json()
        return response_data["choices"][0]["message"]["content"]
    else:
        logger.error(f"Error calling Azure OpenAI: {response.status_code} - {response.text}")
        raise Exception(f"Azure OpenAI API error: {response.text}")

def generate_mock_response(message, conversation_history, workflow=None):
    """
    Generate a mock response for development and testing.
    
    Args:
        message (str): User's message
        conversation_history (list): Previous conversation messages
        workflow (str): Current workflow context (account, loan, products)
        
    Returns:
        str: Simulated AI response
    """
    message_lower = message.lower()
    
    # Check if this is likely a workflow switch request
    account_keywords = ["open account", "new account", "checking account", "savings account", "bank account"]
    loan_keywords = ["loan", "borrow money", "mortgage", "financing", "credit"]
    product_keywords = ["products", "services", "information", "details", "rates", "fees"]
    
    # Check for special reset keywords to restart the conversation
    reset_keywords = ["restart", "reset", "start over", "new conversation", "different service", "something else"]
    
    # Track the conversation state based on history
    conversation_state = analyze_conversation_state(conversation_history)
    
    # Debug the current state
    logger.debug(f"Current conversation state: {conversation_state}")
    
    # Check if this is a reset request or if multiple "no" responses were detected
    if any(keyword in message_lower for keyword in reset_keywords) or (
        # If the special multiple "no" counter has been triggered
        conversation_state.get('reset_conversation', False)
    ) or (
        # If user says "no" after account completion
        workflow == "account" and conversation_state.get('account_completed', False) and message_lower.strip() in ['no', 'nope', 'nothing']
    ) or (
        # If account is completed and user wants to move on to something else
        workflow == "account" and conversation_state.get('account_completed', False) and 
        any(keyword in message_lower for keyword in ["yes", "yeah", "sure", "help"]) and
        any(keyword in message_lower for keyword in loan_keywords + product_keywords)
    ):
        # Reset the entire conversation
        logger.debug("Resetting conversation flow")
        # Clear the conversation history
        conversation_history = []
        return "Hello! I'm your AI banking assistant. I can help you with:\n\n1. Opening a new account\n2. Applying for a loan\n3. Information about our banking products\n\nHow can I assist you today?"
    
    # Detect if user is trying to switch workflows
    previous_workflow = workflow
    if workflow != "account" and any(keyword in message_lower for keyword in account_keywords):
        # User wants to switch to account workflow
        logger.debug("User wants to switch to account workflow")
        workflow = "account"
        # Clear the conversation history
        conversation_history = []
        return "I'd be happy to help you open a new bank account. To get started, could you please tell me your full name?"
    
    elif workflow != "loan" and any(keyword in message_lower for keyword in loan_keywords):
        # User wants to switch to loan workflow  
        logger.debug("User wants to switch to loan workflow")
        workflow = "loan"
        # Clear the conversation history
        conversation_history = []
        return "I'll help you with your loan application. Let's start with your personal information. Could you please tell me your full name?"
    
    elif workflow != "products" and any(keyword in message_lower for keyword in product_keywords):
        # User wants to switch to products workflow
        logger.debug("User wants to switch to products workflow")
        workflow = "products"
        # Clear the conversation history
        conversation_history = []
        return "I'd be happy to tell you about our banking products and services. What type of products are you interested in learning about? We offer various accounts, loans, and investment options."
    
    # If workflow didn't change, proceed with normal conversation analysis
    logger.debug(f"Using workflow: {workflow}")
    
    # If a specific workflow is active, prioritize responses for that workflow
    if workflow == "account":
        # Account opening workflow stages
        if conversation_state.get('collect_name', False) or not conversation_state:
            # Ask for name if not already collected
            if "my name is" in message_lower or "name:" in message_lower or len(message.split()) <= 3:
                return "Thank you. To proceed with opening your account, I need to collect some personal information. Could you please share your date of birth in YYYY-MM-DD format?"
            else:
                return "I need to collect some personal information to open your account. Could you please tell me your full name?"
        
        elif conversation_state.get('collect_dob', False):
            # Process DOB
            if any(keyword in message_lower for keyword in ["birth", "dob", "born"]) or has_date_format(message):
                return "Thank you. Now, I need your current residential address, including street, city, state, and zip code."
            else:
                return "I need your date of birth in YYYY-MM-DD format to proceed. This is required for verification purposes."
        
        elif conversation_state.get('collect_address', False):
            # Process address - this should only happen if we haven't collected email yet
            if len(message.split()) >= 4:  # Simple check for a potentially valid address
                return "Great! I also need your email address for communication purposes."
            else:
                return "Please provide your complete residential address including street, city, state, and zip code."
        
        elif conversation_state.get('collect_email', False):
            # Process email
            if '@' in message and '.' in message:
                return "Thank you. Could you also provide your phone number?"
            else:
                return "Please provide a valid email address where we can send account information and updates."
        
        elif conversation_state.get('collect_phone', False):
            # Process phone
            if any(c.isdigit() for c in message) and len([c for c in message if c.isdigit()]) >= 7:
                return "Would you like to upload an ID document for verification, or would you prefer to proceed without document verification? Uploading a document makes the verification process faster."
            else:
                return "Please provide a valid phone number where we can reach you."
        
        elif conversation_state.get('id_verification', False):
            # Check if user wants to upload document
            if any(keyword in message_lower for keyword in ["upload", "yes", "document", "verification", "faster"]):
                return "Great! Please use the document upload button below to upload a clear image of your ID document (like a driver's license or passport). I'll extract your information from it."
            elif any(keyword in message_lower for keyword in ["no", "skip", "proceed", "without", "manual"]):
                # User wants to skip document upload
                return "I'll now verify your identity using the information you've provided. What type of account would you like to open? We offer Basic Checking, Premium Checking, Essential Savings, and Premium Savings accounts."
            else:
                return "Would you like to upload an ID document for verification? Please respond with 'yes' to upload or 'no' to proceed without document verification."
        
        elif conversation_state.get('document_uploaded', False) or conversation_state.get('select_account_type', False):
            # After document upload or if skipped, ask about account type
            if any(keyword in message_lower for keyword in ["basic", "premium", "checking", "savings", "essential"]):
                account_type = "Basic Checking"
                if "premium" in message_lower:
                    if "checking" in message_lower:
                        account_type = "Premium Checking"
                    elif "savings" in message_lower:
                        account_type = "Premium Savings"
                elif "essential" in message_lower and "savings" in message_lower:
                    account_type = "Essential Savings"
                
                # Now run verification checks
                return f"Thank you for selecting {account_type}. I'll now run two important checks:\n\n1. Identity Verification (IDV)\n2. Compliance Check (OFAC Screening)\n\nThese are required regulatory checks before we can open your account. This will only take a moment..."
            else:
                return "Which type of account would you like to open? We offer Basic Checking, Premium Checking, Essential Savings, and Premium Savings accounts."
        
        elif conversation_state.get('running_verifications', False):
            # Running verifications - after this message completes, the state will transition to account_completed
            return "Great news! Both your identity verification and compliance check have passed successfully. Your new account has been created and your account number will be sent to your email. Is there anything else you'd like to know about your new account?"
        
        elif conversation_state.get('account_completed', False):
            # Account is already completed
            
            # Check for a simple yes/no response which would indicate we need to reset
            if message_lower.strip() in ['no', 'nope', 'nothing']:
                # Force a reset to welcome message
                logger.debug("Account completed and user responded with 'no' - resetting to welcome message")
                # Clear the conversation history
                conversation_history = []
                return "Hello! I'm your AI banking assistant. I can help you with:\n\n1. Opening a new account\n2. Applying for a loan\n3. Information about our banking products\n\nHow can I assist you today?"
            
            elif message_lower.strip() in ['yes', 'yeah', 'yep', 'sure', 'ok', 'okay']:
                # User wants to know more, offer specific topics
                return "Great! What would you like to know about your new account? I can help with:\n\n1. Interest rates\n2. Account fees\n3. Debit card information\n4. Online banking features\n5. Or I can tell you about our loan products if you're interested"
            
            # Handle specific queries about the account
            elif "interest" in message_lower or "rate" in message_lower:
                return "Our current interest rates are: 0.05% for Basic Checking, 0.15% for Premium Checking, 1.25% for Essential Savings, and 1.75% for Premium Savings. Is there anything else you'd like to know about your account features?"
            elif "fee" in message_lower or "charge" in message_lower:
                return "Basic Checking has a $5 monthly fee, waived with direct deposit. Premium Checking has a $15 monthly fee, waived with a minimum balance of $5,000. Essential Savings has no fee, and Premium Savings has a $10 fee waived with a minimum balance of $10,000. Would you like to learn about other features?"
            elif "card" in message_lower or "debit" in message_lower:
                return "Your debit card will be mailed within 7-10 business days. You can use it for purchases worldwide and at ATMs. Need assistance with anything else?"
            elif "loan" in message_lower or "borrow" in message_lower:
                return "Now that your account is set up, would you like to learn about our loan products? We offer home mortgages, auto loans, and personal loans with competitive rates. Would you like to start a loan application?"
            else:
                return "Thank you for opening an account with us. You can log in to your online banking to view your account details, set up direct deposits, or make transfers. Is there anything else you'd like to know about your new account features?"
        
        else:
            # Default account opening response
            return "I'm helping you open a new account. Could you please provide your full name to proceed with the application?"
    
    elif workflow == "loan":
        # Loan application workflow
        if conversation_state.get('collect_name', False) or not conversation_state:
            # Ask for name if not already collected
            if "my name is" in message_lower or "name:" in message_lower or len(message.split()) <= 3:
                return "Thank you. What type of loan are you interested in? We offer home mortgages, auto loans, and personal loans."
            else:
                return "I need to collect some personal information for your loan application. Could you please tell me your full name?"
        
        elif conversation_state.get('collect_loan_type', False):
            # Process loan type
            loan_type = ""
            if "mortgage" in message_lower or "home" in message_lower:
                loan_type = "Home Mortgage"
            elif "auto" in message_lower or "car" in message_lower:
                loan_type = "Auto Loan"
            elif "personal" in message_lower:
                loan_type = "Personal Loan"
                
            if loan_type:
                return f"Thank you for selecting a {loan_type}. How much would you like to borrow? Please specify the amount."
            else:
                return "Please select a loan type: Home Mortgage, Auto Loan, or Personal Loan."
        
        elif conversation_state.get('collect_loan_amount', False):
            # Process loan amount
            if any(c.isdigit() for c in message):
                return "Great. What is your preferred loan tenure in months? For example, 36 months, 60 months, etc."
            else:
                return "Please specify how much you would like to borrow. For example, $10,000."
        
        elif conversation_state.get('collect_loan_tenure', False):
            # Process loan tenure
            if any(c.isdigit() for c in message):
                return "For credit assessment purposes, what is your approximate monthly income?"
            else:
                return "Please specify your preferred loan tenure in months. For example, 36 months, 60 months, etc."
        
        elif conversation_state.get('collect_income', False):
            # Process income
            if any(c.isdigit() for c in message):
                return "Thank you for providing your financial information. I'll need to perform a credit assessment to determine your loan eligibility and interest rate. This will only take a moment..."
            else:
                return "Please specify your approximate monthly income. This information is needed for credit assessment."
        
        elif conversation_state.get('running_credit_check', False):
            # Credit assessment
            return "Good news! Based on your information, your loan application has been pre-approved with a credit score of 720. The final approval is subject to document verification. Would you like to proceed with the application?"
        
        elif conversation_state.get('loan_approved', False):
            # Loan approved
            return "Your loan application has been submitted successfully. A loan officer will contact you shortly to guide you through the rest of the process. Is there anything else you'd like to know about your loan?"
        
        else:
            # Default loan application response
            return "I'm helping you apply for a loan. Could you please provide your full name to get started?"
    
    elif workflow == "products":
        # Bank product information workflow
        if "savings" in message_lower:
            return "Our savings accounts offer competitive interest rates. The Essential Savings account has a 2.5% interest rate with a $500 minimum balance, while the Premium Savings account offers 3.2% with a $5,000 minimum balance."
        elif "checking" in message_lower:
            return "We offer Basic Checking with no monthly fees and Premium Checking with enhanced features for a $15 monthly fee (waived with $2,500 minimum balance)."
        elif "mortgage" in message_lower or "home loan" in message_lower:
            return "Our home mortgage rates currently start at 4.5% for a 30-year fixed-rate mortgage and 3.9% for a 15-year fixed-rate mortgage. We also offer adjustable-rate options."
        elif "auto" in message_lower or "car" in message_lower:
            return "Our auto loan rates start at 3.9% for new vehicles and 4.5% for used vehicles. Loan terms range from 36 to 72 months."
        elif "personal" in message_lower:
            return "Our personal loans offer rates starting at 7.9%, with loan amounts from $2,000 to $25,000 and terms up to 60 months."
        elif "interest" in message_lower or "rate" in message_lower:
            return "Our current interest rates vary by product. Savings accounts range from 2.5-3.2%, mortgage rates from 3.9-5.5%, and personal loans from 7.9-15.9% depending on credit score."
        elif "fee" in message_lower:
            return "We aim to keep our fees transparent and minimal. Basic Checking has no monthly fee, Premium Checking has a $15 monthly fee (waived with $2,500 balance), and there are no account opening or closing fees."
        else:
            return "I can provide information about our various banking products including savings accounts, checking accounts, mortgages, auto loans, and personal loans. What specific product would you like to learn about?"
    
    # If no specific workflow or general questions
    else:
        # Account opening intent
        if any(keyword in message_lower for keyword in ["open account", "new account", "create account", "savings account", "checking account"]):
            return "I can help you open a new account. We'll need some personal information. Would you like to enter your details manually or upload an identification document like a driver's license or passport?"
        
        # Document upload follow-up
        elif any(keyword in message_lower for keyword in ["upload", "document", "id", "license", "passport", "scan"]):
            return "Great! Please use the document upload button below to upload a clear image of your ID document. I'll extract your information from it."
        
        # Loan application intent
        elif any(keyword in message_lower for keyword in ["loan", "borrow", "mortgage", "home loan", "car loan", "auto loan"]):
            if "car" in message_lower or "auto" in message_lower:
                return "I can help you apply for an auto loan. We offer competitive rates starting at 3.9%. Would you like to start the application process?"
            elif "home" in message_lower or "mortgage" in message_lower or "house" in message_lower:
                return "I can help you apply for a home mortgage. Our rates currently start at 4.5%. Would you like to start the application process?"
            else:
                return "I can help you apply for a loan. We offer various types including home mortgages, auto loans, and personal loans. What type of loan are you interested in?"
        
        # Bank product queries
        elif any(keyword in message_lower for keyword in ["interest rate", "rates", "fees", "product", "offer", "details"]):
            if "savings" in message_lower:
                return "Our savings accounts offer competitive interest rates. The Essential Savings account has a 2.5% interest rate with a $500 minimum balance, while the Premium Savings account offers 3.2% with a $5,000 minimum balance."
            elif "checking" in message_lower:
                return "We offer Basic Checking with no monthly fees and Premium Checking with enhanced features for a $15 monthly fee (waived with $2,500 minimum balance)."
            else:
                return "We offer a variety of banking products including savings accounts, checking accounts, and loans. What specific product would you like to know more about?"
        
        # Greeting
        elif any(keyword in message_lower for keyword in ["hello", "hi", "hey", "greetings", "good morning", "good afternoon", "good evening"]):
            return "Hello! I'm your AI banking assistant. I can help you open an account, apply for a loan, or answer questions about our banking products. How can I assist you today?"
        
        # Default response
        else:
            return "I'm here to help with banking services like opening accounts, applying for loans, or answering questions about our products. How can I assist you today?"
