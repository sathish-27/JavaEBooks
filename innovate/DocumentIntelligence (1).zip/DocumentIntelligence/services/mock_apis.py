import random
import string
import uuid
import json
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

def verify_id(name, dob, address):
    """
    Mock ID verification service.
    
    Args:
        name (str): Full name
        dob (str): Date of birth
        address (str): Address
        
    Returns:
        dict: Verification result
    """
    logger.debug(f"Verifying ID for: {name}")
    
    # Validate inputs
    if not all([name, dob, address]):
        return {
            "status": "failure",
            "message": "Missing required information for ID verification"
        }
    
    # Generate a deterministic verification result based on the name
    # In a real system, this would call an actual verification service
    verification_success = len(name) % 10 != 0  # Simple deterministic logic
    
    if verification_success:
        return {
            "status": "success",
            "message": "Identity verified successfully",
            "verification_id": str(uuid.uuid4())
        }
    else:
        return {
            "status": "failure",
            "message": "Unable to verify identity. Please provide additional information."
        }

def check_compliance(name, dob):
    """
    Mock compliance check (OFAC Screening).
    
    Args:
        name (str): Full name
        dob (str): Date of birth
        
    Returns:
        dict: Compliance check result
    """
    logger.debug(f"Performing compliance check for: {name}")
    
    # Validate inputs
    if not all([name, dob]):
        return {
            "status": "failure",
            "message": "Missing required information for compliance check"
        }
    
    # Check against a mock "denied persons list"
    # In a real system, this would check against actual compliance databases
    denied_names = ["Denied Person", "Sanctioned Individual", "Blocked Entity"]
    
    if any(denied_name.lower() in name.lower() for denied_name in denied_names):
        return {
            "status": "failure",
            "message": "Compliance check failed. Please contact customer support."
        }
    else:
        return {
            "status": "success",
            "message": "Compliance check completed successfully",
            "compliance_id": str(uuid.uuid4())
        }

def assess_credit(monthly_income, loan_amount, loan_tenure):
    """
    Mock credit assessment.
    
    Args:
        monthly_income (float): Monthly income
        loan_amount (float): Requested loan amount
        loan_tenure (int): Loan tenure in months
        
    Returns:
        dict: Credit assessment result
    """
    logger.debug(f"Assessing credit for loan amount: {loan_amount}")
    
    # Validate inputs
    if not all([monthly_income, loan_amount, loan_tenure]):
        return {
            "status": "failure",
            "message": "Missing required information for credit assessment"
        }
    
    # Convert inputs to numbers if they're strings
    try:
        monthly_income = float(monthly_income)
        loan_amount = float(loan_amount)
        loan_tenure = int(loan_tenure)
    except (ValueError, TypeError):
        return {
            "status": "failure",
            "message": "Invalid input data types for credit assessment"
        }
    
    # Simple credit assessment logic
    # In a real system, this would use complex credit scoring models
    debt_to_income_ratio = (loan_amount / loan_tenure) / monthly_income
    
    # Generate credit score (300-850)
    base_score = 650  # Average credit score
    income_factor = min(monthly_income / 1000, 100)  # Cap at 100 points
    ratio_penalty = debt_to_income_ratio * 100  # Higher ratio means lower score
    
    credit_score = int(min(max(base_score + income_factor - ratio_penalty, 300), 850))
    
    # Determine approval status
    if credit_score >= 700:
        status = "approved"
        message = "Credit assessment approved with excellent score."
    elif credit_score >= 650:
        status = "approved"
        message = "Credit assessment approved with good score."
    elif credit_score >= 600:
        status = "approved"
        message = "Credit assessment approved with fair score."
    else:
        status = "rejected"
        message = "Credit assessment not approved. Score below minimum threshold."
    
    return {
        "credit_score": credit_score,
        "status": status,
        "message": message,
        "debt_to_income_ratio": round(debt_to_income_ratio, 2),
        "assessment_id": str(uuid.uuid4())
    }

def create_account(name, dob, address):
    """
    Mock account creation.
    
    Args:
        name (str): Full name
        dob (str): Date of birth
        address (str): Address
        
    Returns:
        dict: Account creation result
    """
    logger.debug(f"Creating account for: {name}")
    
    # Validate inputs
    if not all([name, dob, address]):
        return {
            "status": "failure",
            "message": "Missing required information for account creation"
        }
    
    # Generate a random account number
    account_number = ''.join(random.choices(string.digits, k=10))
    
    return {
        "account_number": account_number,
        "status": "success",
        "message": "Account created successfully",
        "account_type": "Basic Checking",
        "creation_date": datetime.now().strftime('%Y-%m-%d')
    }

def generate_loan_underwriting(loan_details, credit_assessment):
    """
    Mock loan underwriting document generation.
    
    Args:
        loan_details (dict): Loan application details
        credit_assessment (dict): Credit assessment result
        
    Returns:
        dict: Loan underwriting result
    """
    logger.debug("Generating loan underwriting document")
    
    # Validate inputs
    if not loan_details:
        return {
            "status": "failure",
            "message": "Missing loan details for underwriting"
        }
    
    # Generate a mock underwriting document
    # In a real system, this would generate a detailed document
    document = {
        "loan_id": str(uuid.uuid4()),
        "applicant_name": loan_details.get("name", "Unknown"),
        "loan_amount": loan_details.get("loan_amount", "0"),
        "loan_term": loan_details.get("loan_tenure", "0") + " months",
        "interest_rate": "5.25%",
        "monthly_payment": "$" + str(round(float(loan_details.get("loan_amount", 0)) / float(loan_details.get("loan_tenure", 1)) * 1.0525, 2)),
        "credit_score": credit_assessment.get("credit_score", "Unknown"),
        "credit_status": credit_assessment.get("status", "Unknown"),
        "underwriting_date": datetime.now().strftime('%Y-%m-%d'),
        "approval_status": "Pending Officer Review"
    }
    
    return {
        "document": json.dumps(document, indent=2),
        "status": "success",
        "message": "Loan underwriting document generated successfully"
    }
