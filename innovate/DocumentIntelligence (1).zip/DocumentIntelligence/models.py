from datetime import datetime
from app import db

class Customer(db.Model):
    """Customer information collected during onboarding"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    dob = db.Column(db.String(20), nullable=False)  # Store as string in format YYYY-MM-DD
    address = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(100), nullable=True)
    phone = db.Column(db.String(20), nullable=True)
    document_type = db.Column(db.String(50), nullable=True)  # Type of ID document uploaded
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    accounts = db.relationship('Account', backref='customer', lazy=True)
    loan_applications = db.relationship('LoanApplication', backref='customer', lazy=True)

class Account(db.Model):
    """Bank account information"""
    id = db.Column(db.Integer, primary_key=True)
    account_number = db.Column(db.String(20), unique=True, nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    account_type = db.Column(db.String(50), nullable=False)  # e.g., "Basic Checking", "Premium Savings"
    status = db.Column(db.String(20), nullable=False, default="Active")  # Active, Closed, Suspended
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class LoanApplication(db.Model):
    """Loan application information"""
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    loan_type = db.Column(db.String(50), nullable=False)  # e.g., "Home Mortgage", "Auto Loan", "Personal Loan"
    loan_amount = db.Column(db.Float, nullable=False)
    loan_tenure = db.Column(db.Integer, nullable=False)  # in months
    monthly_income = db.Column(db.Float, nullable=False)
    credit_score = db.Column(db.Integer, nullable=True)
    status = db.Column(db.String(20), nullable=False)  # "Pending", "Approved", "Rejected"
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class VerificationRecord(db.Model):
    """Records of verification checks performed"""
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    check_type = db.Column(db.String(50), nullable=False)  # "ID Verification", "Compliance Check", "Credit Assessment"
    status = db.Column(db.String(20), nullable=False)  # "Success", "Failure"
    message = db.Column(db.String(255), nullable=True)
    verification_id = db.Column(db.String(50), nullable=True)  # ID returned by verification system
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Conversation(db.Model):
    """Chat conversation history for audit purposes"""
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=True)  # Can be null if user hasn't been identified yet
    message = db.Column(db.Text, nullable=False)
    is_bot = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)