import os
import json
import logging
import uuid
from flask import render_template, request, jsonify, session
from datetime import datetime

from app import app, db
from services.openai_service import process_user_message, analyze_conversation_state
from services.document_scanner import scan_document
from services.mock_apis import (
    verify_id, check_compliance, assess_credit,
    create_account, generate_loan_underwriting
)
from config import BANK_PRODUCTS
from models import Customer, Account, LoanApplication, VerificationRecord, Conversation

logger = logging.getLogger(__name__)

@app.route('/')
def index():
    """Render the home page with the chat widget."""
    return render_template('index.html', bank_products=BANK_PRODUCTS)

@app.route('/chat', methods=['POST'])
def chat():
    """Process incoming chat messages and return AI responses."""
    try:
        data = request.json
        message = data.get('message', '')
        conversation_history = data.get('conversation_history', [])
        customer_id = session.get('customer_id')
        workflow = data.get('workflow', '')  # Workflow can be 'account', 'loan', or 'products'
        
        # Check for workflow switch keywords in the message
        message_lower = message.lower()
        account_keywords = ["open account", "new account", "checking account", "savings account", "bank account"]
        loan_keywords = ["apply for loan", "need a loan", "loan application", "borrow money", "mortgage", "auto loan"]
        product_keywords = ["bank products", "product information", "banking services", "investment options"]
        
        # Handle workflow switching
        if workflow != "account" and any(keyword in message_lower for keyword in account_keywords):
            logger.debug("Potential workflow switch to account detected")
            # Clear session state and set new workflow
            session.clear()
            session['workflow'] = "account"
            workflow = "account"
            # Only keep the most recent message in conversation history
            conversation_history = []
        elif workflow != "loan" and any(keyword in message_lower for keyword in loan_keywords):
            logger.debug("Potential workflow switch to loan detected")
            # Clear session state and set new workflow
            session.clear()
            session['workflow'] = "loan"
            workflow = "loan"
            # Only keep the most recent message in conversation history
            conversation_history = []
        elif workflow != "products" and any(keyword in message_lower for keyword in product_keywords):
            logger.debug("Potential workflow switch to products detected")
            # Clear session state and set new workflow
            session.clear()
            session['workflow'] = "products"
            workflow = "products"
            # Only keep the most recent message in conversation history
            conversation_history = []
        elif workflow and workflow != session.get('workflow'):
            # Update session to match workflow from frontend
            logger.debug(f"Updating session workflow to {workflow}")
            session['workflow'] = workflow
            session.pop('conversation_state', None)
        
        logger.debug(f"Received message: {message}")
        logger.debug(f"Current workflow: {workflow}")
        
        # Special check to avoid the email→DOB loop issue - clear the conversation state when needed
        if workflow == "account":
            conversation_state = analyze_conversation_state(conversation_history)
            if conversation_state.get('collect_email') and conversation_state.get('collect_dob'):
                logger.debug("Detected conflicting state with both email and DOB collection active")
                # Remove DOB collection from the state to avoid loops
                if 'collect_dob' in conversation_state:
                    del conversation_state['collect_dob']
                    logger.debug("Removed conflicting DOB collection flag")
        
        # Store user message in database
        user_conversation = Conversation(
            customer_id=customer_id,
            message=message,
            is_bot=False
        )
        db.session.add(user_conversation)
        db.session.commit()
        
        # Special case: detect 'no' response after account completion
        if workflow == "account" and message.lower().strip() in ["no", "nope", "nothing", "n"]:
            # Check if we're in account_completed state by examining bot messages
            if conversation_history:
                bot_messages = [msg.get('text', '') for msg in conversation_history if msg.get('is_bot', False)]
                account_completion_phrases = [
                    "great news", "both your identity verification", 
                    "account has been created", "account number will be sent",
                    "passed successfully", "thank you for opening an account",
                    "would you like to know about your new account"
                ]
                
                # If we've recently completed an account and user says "no"
                if any(phrase in " ".join(bot_messages[-3:]).lower() for phrase in account_completion_phrases):
                    logger.debug("FORCE RESET TRIGGERED: Account completed and user said 'no'")
                    # Reset workflow and session
                    session.clear()
                    session['workflow'] = None
                    welcome_message = "Hello! I'm your AI banking assistant. I can help you with:\n\n1. Opening a new account\n2. Applying for a loan\n3. Information about our banking products\n\nHow can I assist you today?"
                    
                    # Store bot response in database
                    bot_conversation = Conversation(
                        customer_id=customer_id,
                        message=welcome_message,
                        is_bot=True
                    )
                    db.session.add(bot_conversation)
                    db.session.commit()
                    
                    return jsonify({"response": welcome_message, "workflow": None, "reset": True})
        
        # Process the message using Azure OpenAI with workflow context
        response = process_user_message(message, conversation_history, workflow)
        
        # Store bot response in database
        bot_conversation = Conversation(
            customer_id=customer_id,
            message=response,
            is_bot=True
        )
        db.session.add(bot_conversation)
        db.session.commit()
        
        # Check if response contains welcome message, which indicates a reset
        if "Hello! I'm your AI banking assistant. I can help you with:" in response:
            return jsonify({"response": response, "workflow": None, "reset": True})
        
        return jsonify({"response": response, "workflow": workflow})
    
    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/workflow-selection', methods=['POST'])
def workflow_selection():
    """Handle workflow selection and intent detection."""
    try:
        data = request.json
        message = data.get('message', '')
        prev_workflow = data.get('workflow', '')
        
        logger.debug(f"Detected intent: {prev_workflow} for message: {message}")
        
        # More robust intent detection with stronger keyword matching
        # In a real application, this would use Azure OpenAI for intent detection
        intent = "general"
        
        # Define more explicit keywords for each workflow
        account_keywords = ["open account", "new account", "create account", "checking account", "savings account", "bank account"]
        loan_keywords = ["apply for loan", "need a loan", "loan application", "borrow money", "mortgage", "auto loan"]
        product_keywords = ["bank products", "product information", "banking services", "investment options"]
        
        # Check for workflow switch
        if prev_workflow and prev_workflow != "general":
            # We already have a workflow, check if user wants to switch
            if prev_workflow != "account" and any(keyword in message.lower() for keyword in account_keywords):
                logger.debug(f"Switching workflow from {prev_workflow} to account")
                intent = "account"
                # Reset all session state and conversation context
                session.clear()
            elif prev_workflow != "loan" and any(keyword in message.lower() for keyword in loan_keywords):
                logger.debug(f"Switching workflow from {prev_workflow} to loan")
                intent = "loan"
                # Reset all session state and conversation context
                session.clear()
            elif prev_workflow != "products" and any(keyword in message.lower() for keyword in product_keywords):
                logger.debug(f"Switching workflow from {prev_workflow} to products")
                intent = "products"
                # Reset all session state and conversation context
                session.clear()
            else:
                # No clear switch intent, keep current workflow
                intent = prev_workflow
        else:
            # Initial workflow detection with broader matching
            if any(keyword in message.lower() for keyword in account_keywords + ["account", "open", "create"]):
                intent = "account"
            elif any(keyword in message.lower() for keyword in loan_keywords + ["loan", "borrow"]):
                intent = "loan"
            elif any(keyword in message.lower() for keyword in product_keywords + ["product", "service", "information"]):
                intent = "products"
            
            # Clear session state for new workflow
            if intent != "general":
                session.pop('conversation_state', None)
        if session.get('workflow') != intent and intent != "general":
            logger.debug(f"Switching workflow from {session.get('workflow', 'none')} to {intent}")
            session['workflow'] = intent
        
        # Store this initial interaction in the database
        customer_id = session.get('customer_id')
        user_conversation = Conversation(
            customer_id=customer_id,
            message=message,
            is_bot=False
        )
        db.session.add(user_conversation)
        
        # Default responses based on the detected intent
        if intent == "account":
            response = "Great! I'll help you open a new bank account. To proceed, I need to collect some personal information. Could you please tell me your full name?"
        elif intent == "loan":
            response = "I'd be happy to help you with a loan application. I'll need to gather some information about you and the loan you're interested in. Let's begin with your full name."
        elif intent == "products":
            response = "I'll be glad to tell you about our banking products and services. We offer a range of accounts, loans, and investment options. What specific type of product are you interested in?"
        else:
            response = "Welcome to our banking service! I can help you open a new account, apply for a loan, or learn about our products. How can I assist you today?"
        
        # Store the bot response
        bot_conversation = Conversation(
            customer_id=customer_id,
            message=response,
            is_bot=True
        )
        db.session.add(bot_conversation)
        db.session.commit()

        logger.debug(f"Detected intent: {intent} for message: {message}")
        
        return jsonify({"intent": intent, "response": response})
    
    except Exception as e:
        logger.error(f"Error in workflow selection: {str(e)}")
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@app.route('/api/document-scanning', methods=['POST'])
def document_scanning():
    """
    Document scanning endpoint to extract information from uploaded documents
    and update customer records in the database.
    """
    try:
        if 'document' not in request.files:
            return jsonify({"error": "No document file uploaded"}), 400
        
        document_file = request.files['document']
        document_type = request.form.get('document_type', 'ID')
        
        if document_file.filename == '':
            return jsonify({"error": "Empty file submitted"}), 400
        
        # Process the document and extract information
        extracted_data = scan_document(document_file)
        customer_id = session.get('customer_id')
        
        # If customer exists in the session, update their document information
        if customer_id:
            customer = Customer.query.get(customer_id)
            if customer:
                # Update customer information if available
                if 'name' in extracted_data and extracted_data['name']:
                    customer.name = extracted_data['name']
                if 'dob' in extracted_data and extracted_data['dob']:
                    customer.dob = extracted_data['dob']
                if 'address' in extracted_data and extracted_data['address']:
                    customer.address = extracted_data['address']
                
                # Update document type
                customer.document_type = document_type
                
                # Add verification record
                verification = VerificationRecord(
                    customer_id=customer_id,
                    check_type='Document Scan',
                    status='Success',
                    message=f'Document type: {document_type}',
                    verification_id=f"DOC-{uuid.uuid4().hex[:8]}"
                )
                db.session.add(verification)
                
                db.session.commit()
                
                # Add customer info to the response
                extracted_data['customer_id'] = customer_id
        
        return jsonify({
            "extracted_data": extracted_data,
            "status": "success",
            "message": "Document scanned successfully"
        })
    
    except Exception as e:
        logger.error(f"Error in document scanning: {str(e)}")
        db.session.rollback()
        return jsonify({
            "status": "failure", 
            "message": f"Error processing document: {str(e)}"
        }), 500

@app.route('/api/id-verification', methods=['POST'])
def id_verification():
    """Mock endpoint for ID verification."""
    try:
        data = request.json
        result = verify_id(data.get('name'), data.get('dob'), data.get('address'))
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error in ID verification: {str(e)}")
        return jsonify({"status": "failure", "message": str(e)}), 500

@app.route('/api/compliance-check', methods=['POST'])
def compliance_check():
    """Mock endpoint for compliance check (OFAC Screening)."""
    try:
        data = request.json
        result = check_compliance(data.get('name'), data.get('dob'))
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error in compliance check: {str(e)}")
        return jsonify({"status": "failure", "message": str(e)}), 500

@app.route('/api/credit-assessment', methods=['POST'])
def credit_assessment():
    """Mock endpoint for credit assessment."""
    try:
        data = request.json
        result = assess_credit(
            data.get('monthly_income', 0), 
            data.get('loan_amount', 0), 
            data.get('loan_tenure', 0)
        )
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error in credit assessment: {str(e)}")
        return jsonify({"status": "failure", "message": str(e)}), 500

@app.route('/api/account-creation', methods=['POST'])
def account_creation():
    """Endpoint for account creation that stores customer information in the database."""
    try:
        data = request.json
        name = data.get('name', '')
        dob = data.get('dob', '')
        address = data.get('address', '')
        email = data.get('email', '')
        phone = data.get('phone', '')
        document_type = data.get('document_type', '')
        account_type = data.get('account_type', 'Basic Checking')
        
        # Call the mock API for account creation
        result = create_account(name, dob, address)
        
        if result.get('status') == 'success':
            # Create a new customer record
            customer = Customer(
                name=name,
                dob=dob,
                address=address,
                email=email,
                phone=phone,
                document_type=document_type
            )
            db.session.add(customer)
            db.session.flush()  # Flush to get the customer ID
            
            # Create a new account record
            account = Account(
                account_number=result.get('account_number', f"ACC-{uuid.uuid4().hex[:8]}"),
                customer_id=customer.id,
                account_type=account_type,
                status='Active'
            )
            db.session.add(account)
            
            # Store the customer ID in the session
            session['customer_id'] = customer.id
            
            # Add verification record
            verification = VerificationRecord(
                customer_id=customer.id,
                check_type='ID Verification',
                status='Success',
                message='ID verification passed',
                verification_id=f"VER-{uuid.uuid4().hex[:8]}"
            )
            db.session.add(verification)
            
            db.session.commit()
            
            # Add customer ID to result
            result['customer_id'] = customer.id
        
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error in account creation: {str(e)}")
        db.session.rollback()
        return jsonify({"status": "failure", "message": str(e)}), 500

@app.route('/api/loan-application', methods=['POST'])
def loan_application():
    """Endpoint for loan application that stores information in the database."""
    try:
        data = request.json
        customer_id = session.get('customer_id')
        loan_type = data.get('loan_type', '')
        loan_amount = float(data.get('loan_amount', 0))
        loan_tenure = int(data.get('loan_tenure', 0))
        monthly_income = float(data.get('monthly_income', 0))
        
        # If there's no customer ID in the session yet
        if not customer_id and data.get('customer_data'):
            customer_data = data.get('customer_data', {})
            # Create a new customer
            customer = Customer(
                name=customer_data.get('name', ''),
                dob=customer_data.get('dob', ''),
                address=customer_data.get('address', ''),
                email=customer_data.get('email', ''),
                phone=customer_data.get('phone', '')
            )
            db.session.add(customer)
            db.session.flush()
            
            customer_id = customer.id
            session['customer_id'] = customer_id
        
        # Call mock credit assessment API
        credit_result = assess_credit(monthly_income, loan_amount, loan_tenure)
        credit_score = credit_result.get('credit_score', 0)
        approval_status = credit_result.get('status', 'Pending')
        
        # Create loan application record
        loan = LoanApplication(
            customer_id=customer_id,
            loan_type=loan_type,
            loan_amount=loan_amount,
            loan_tenure=loan_tenure,
            monthly_income=monthly_income,
            credit_score=credit_score,
            status=approval_status
        )
        db.session.add(loan)
        
        # Add verification record for credit assessment
        verification = VerificationRecord(
            customer_id=customer_id,
            check_type='Credit Assessment',
            status='Success',
            message=f'Credit score: {credit_score}',
            verification_id=f"CR-{uuid.uuid4().hex[:8]}"
        )
        db.session.add(verification)
        
        db.session.commit()
        
        # Generate loan underwriting document if approved
        result = {
            "status": approval_status,
            "loan_application_id": loan.id,
            "credit_score": credit_score,
            "message": "Loan application submitted successfully"
        }
        
        if approval_status == 'Approved':
            underwriting_result = generate_loan_underwriting(
                {"loan_type": loan_type, "loan_amount": loan_amount, "loan_tenure": loan_tenure},
                credit_result
            )
            result.update(underwriting_result)
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Error in loan application: {str(e)}")
        db.session.rollback()
        return jsonify({"status": "failure", "message": str(e)}), 500

@app.route('/api/loan-underwriting', methods=['POST'])
def loan_underwriting():
    """Mock endpoint for loan underwriting."""
    try:
        data = request.json
        result = generate_loan_underwriting(
            data.get('loan_details', {}), 
            data.get('credit_assessment', {})
        )
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error in loan underwriting: {str(e)}")
        return jsonify({"status": "failure", "message": str(e)}), 500

@app.route('/api/customer', methods=['GET'])
def get_customer():
    """Endpoint to retrieve the current customer data."""
    customer_id = session.get('customer_id')
    
    if not customer_id:
        return jsonify({"status": "failure", "message": "No customer found in session"}), 404
    
    try:
        customer = Customer.query.get(customer_id)
        
        if not customer:
            return jsonify({"status": "failure", "message": "Customer not found"}), 404
        
        # Get the customer's accounts
        accounts = [
            {
                "id": account.id,
                "account_number": account.account_number,
                "account_type": account.account_type,
                "status": account.status,
                "created_at": account.created_at.isoformat()
            }
            for account in customer.accounts
        ]
        
        # Get the customer's loan applications
        loan_applications = [
            {
                "id": loan.id,
                "loan_type": loan.loan_type,
                "loan_amount": loan.loan_amount,
                "loan_tenure": loan.loan_tenure,
                "status": loan.status,
                "credit_score": loan.credit_score,
                "created_at": loan.created_at.isoformat()
            }
            for loan in customer.loan_applications
        ]
        
        # Return the customer data
        return jsonify({
            "status": "success",
            "customer": {
                "id": customer.id,
                "name": customer.name,
                "dob": customer.dob,
                "address": customer.address,
                "email": customer.email,
                "phone": customer.phone,
                "document_type": customer.document_type,
                "created_at": customer.created_at.isoformat(),
                "accounts": accounts,
                "loan_applications": loan_applications
            }
        })
    
    except Exception as e:
        logger.error(f"Error retrieving customer data: {str(e)}")
        return jsonify({"status": "failure", "message": str(e)}), 500

@app.route('/api/bank-products', methods=['GET'])
def bank_products():
    """Endpoint to retrieve bank product information."""
    product_type = request.args.get('type', None)
    
    if product_type and product_type in BANK_PRODUCTS:
        return jsonify(BANK_PRODUCTS[product_type])
    
    return jsonify(BANK_PRODUCTS)
