/**
 * TrustBank Website Scripts
 * 
 * Main JavaScript file for the banking website
 */

// Initialize the page when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Demo form submission handling
    const contactForm = document.querySelector('#contact form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value;
            
            // Basic validation
            if (!name || !email || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show success message (in a real application, this would send data to the server)
            alert('Thank you for your message. A customer service representative will contact you shortly.');
            
            // Clear the form
            contactForm.reset();
        });
    }
    
    // Product interaction handling
    const productButtons = document.querySelectorAll('.card .btn-primary');
    productButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const productType = e.target.closest('.tab-pane').id;
            const productName = e.target.closest('.card').querySelector('.card-title').textContent;
            
            // Simulate starting the corresponding workflow through the chat widget
            if (productType === 'savings' || productType === 'checking') {
                simulateChatInteraction(`I'd like to open a ${productName} account`);
            } else if (productType === 'loans') {
                simulateChatInteraction(`I'm interested in applying for a ${productName}`);
            }
            
            // Scroll to the chat widget if not visible
            scrollToChat();
        });
    });
    
    // Helper functions
    function simulateChatInteraction(message) {
        // Open the chat widget if it's closed
        const chatWindow = document.getElementById('chatWindow');
        if (!chatWindow.classList.contains('show')) {
            document.getElementById('chatButton').click();
        }
        
        // Set the message in the input field
        const chatInput = document.getElementById('chatInput');
        chatInput.value = message;
        
        // Trigger the send button click after a short delay
        setTimeout(() => {
            document.getElementById('chatSendButton').click();
        }, 500);
    }
    
    function scrollToChat() {
        // Scroll to the bottom of the page where the chat widget is located
        window.scrollTo({
            top: document.body.scrollHeight,
            behavior: 'smooth'
        });
    }
});
