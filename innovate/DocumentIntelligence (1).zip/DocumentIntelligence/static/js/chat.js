/**
 * AI Chat Assistant for Consumer Onboarding
 * 
 * This script handles the chat widget functionality including:
 * - User interactions with the chat interface
 * - Document uploading and scanning
 * - Communication with the backend services
 */

// Store chat history
let conversationHistory = [];
let uploadedDocument = null;

// Initialize chat functionality when DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const chatButton = document.getElementById('chatButton');
    const chatWindow = document.getElementById('chatWindow');
    const chatCloseButton = document.getElementById('chatCloseButton');
    const chatMessages = document.getElementById('chatMessages');
    const chatInput = document.getElementById('chatInput');
    const chatSendButton = document.getElementById('chatSendButton');
    const documentUpload = document.getElementById('documentUpload');
    const documentUploadPreview = document.getElementById('documentUploadPreview');
    const documentName = document.getElementById('documentName');
    const removeDocumentBtn = document.getElementById('removeDocumentBtn');

    // Show chat window automatically after a short delay
    setTimeout(() => {
        chatWindow.classList.add('show');
    }, 2000);

    // Toggle chat window visibility
    chatButton.addEventListener('click', function() {
        chatWindow.classList.toggle('show');
        // Focus on input field when chat is opened
        if (chatWindow.classList.contains('show')) {
            chatInput.focus();
        }
    });

    // Close chat window
    chatCloseButton.addEventListener('click', function() {
        chatWindow.classList.remove('show');
    });

    // Send message when user presses Enter in the input field
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // Send message when user clicks the send button
    chatSendButton.addEventListener('click', sendMessage);

    // Handle document upload
    documentUpload.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;

        // Check file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            addMessage('The file is too large. Please upload a file smaller than 5MB.', 'bot');
            return;
        }

        // Check file type
        const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
        if (!allowedTypes.includes(file.type)) {
            addMessage('Please upload a JPG, PNG, or PDF file.', 'bot');
            return;
        }

        // Store the uploaded document
        uploadedDocument = file;

        // Show preview
        documentName.textContent = file.name;
        documentUploadPreview.classList.remove('d-none');

        // Add message about uploaded document
        addMessage(`I've uploaded my document: ${file.name}`, 'user');

        // Process the document
        processDocument(file);
    });

    // Remove uploaded document
    removeDocumentBtn.addEventListener('click', function() {
        uploadedDocument = null;
        documentUpload.value = '';
        documentUploadPreview.classList.add('d-none');
    });

    // Function to send user message
    function sendMessage() {
        const message = chatInput.value.trim();
        if (message === '') return;

        // Add user message to chat
        addMessage(message, 'user');

        // Clear input field
        chatInput.value = '';

        // Process the message
        processMessage(message);
    }

    // Function to add message to chat window
    function addMessage(message, sender) {
        // Create message element
        const messageEl = document.createElement('div');
        messageEl.className = `message ${sender}`;

        const contentEl = document.createElement('div');
        contentEl.className = 'message-content';

        // Handle message content based on format
        if (typeof message === 'string') {
            // Simple text message
            if (message.includes('\n')) {
                // Handle multiline messages
                const paragraphs = message.split('\n').filter(p => p.trim() !== '');
                paragraphs.forEach(p => {
                    const para = document.createElement('p');
                    para.textContent = p;
                    contentEl.appendChild(para);
                });
            } else {
                contentEl.textContent = message;
            }
        } else if (typeof message === 'object') {
            // Structured message (for displaying extracted data, etc.)
            const para = document.createElement('p');
            para.textContent = message.text || "Here's what I found:";
            contentEl.appendChild(para);

            if (message.data) {
                const list = document.createElement('ul');
                Object.entries(message.data).forEach(([key, value]) => {
                    const item = document.createElement('li');
                    item.textContent = `${key}: ${value}`;
                    list.appendChild(item);
                });
                contentEl.appendChild(list);
            }

            if (message.followup) {
                const followupPara = document.createElement('p');
                followupPara.textContent = message.followup;
                contentEl.appendChild(followupPara);
            }
        }

        messageEl.appendChild(contentEl);
        chatMessages.appendChild(messageEl);

        // Save message to conversation history
        conversationHistory.push({
            text: typeof message === 'string' ? message : JSON.stringify(message),
            is_bot: sender === 'bot'
        });

        // Scroll to bottom of chat
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Store current workflow
    let currentWorkflow = null;
    
    // Function to process user message
    function processMessage(message) {
        // Show typing indicator
        showTypingIndicator();

        // Check if we need to determine intent/workflow
        if (!currentWorkflow && isIntentTrigger(message)) {
            // This might be a workflow selection message, first check intent
            fetch('/api/workflow-selection', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    message: message
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Intent detection failed');
                }
                return response.json();
            })
            .then(data => {
                // Remove typing indicator
                removeTypingIndicator();
                
                // Set current workflow based on intent
                if (data.intent && data.intent !== 'general') {
                    currentWorkflow = data.intent;
                    console.log('Workflow set to: ' + currentWorkflow);
                }
                
                // Add bot response to chat
                addMessage(data.response, 'bot');
                
                // Update current workflow based on the detected intent
                if (data.intent) {
                    console.log(`Setting workflow to: ${data.intent}`);
                    currentWorkflow = data.intent;
                }
            })
            .catch(error => {
                console.error('Error detecting intent:', error);
                removeTypingIndicator();
                
                // Fallback to regular message processing
                processRegularMessage(message);
            });
        } else {
            // Process as a regular message
            processRegularMessage(message);
        }
    }
    
    // Function to check if a message might be a workflow intent trigger
    function isIntentTrigger(message) {
        const messageLower = message.toLowerCase();
        
        // Define more explicit keywords for each workflow
        const accountKeywords = ['open account', 'new account', 'create account', 'checking account', 'savings account', 'bank account'];
        const loanKeywords = ['apply for loan', 'need a loan', 'loan application', 'borrow money', 'mortgage', 'auto loan'];
        const productKeywords = ['bank products', 'product information', 'banking services', 'account types', 'investment options'];
        
        // Check if we need to reset the current workflow (switching workflows)
        if (currentWorkflow) {
            // Check if user wants to switch workflows with clear intent phrases
            if (currentWorkflow !== 'account' && 
                accountKeywords.some(keyword => messageLower.includes(keyword))) {
                console.log("Switching from " + currentWorkflow + " to account workflow");
                currentWorkflow = null; // Reset to allow detection
                conversationHistory = []; // Clear conversation history for a fresh start
                return true;
            } 
            else if (currentWorkflow !== 'loan' && 
                    loanKeywords.some(keyword => messageLower.includes(keyword))) {
                console.log("Switching from " + currentWorkflow + " to loan workflow");
                currentWorkflow = null;
                conversationHistory = []; // Clear conversation history for a fresh start
                return true;
            }
            else if (currentWorkflow !== 'products' && 
                    productKeywords.some(keyword => messageLower.includes(keyword))) {
                console.log("Switching from " + currentWorkflow + " to products workflow");
                currentWorkflow = null;
                conversationHistory = []; // Clear conversation history for a fresh start
                return true;
            }
            
            // If we have an existing workflow and the message doesn't clearly indicate a switch,
            // keep using the current workflow
            return false;
        }
        
        // For first-time workflow detection, use more inclusive keyword matching
        const allKeywords = [
            ...accountKeywords, 'account', 'open', 'create', 
            ...loanKeywords, 'loan', 'apply', 'borrow', 
            ...productKeywords, 'product', 'service', 'information', 'details'
        ];
        
        return allKeywords.some(keyword => messageLower.includes(keyword));
    }
    
    // Function to process a regular chat message
    function processRegularMessage(message) {
        // Check if we should process an account or loan application
        if (extractedCustomerData && currentWorkflow === 'account' && 
            (message.toLowerCase().includes('checking') || message.toLowerCase().includes('savings'))) {
            // Process account opening
            processAccountCreation(message, extractedCustomerData);
            return;
        } else if (extractedCustomerData && currentWorkflow === 'loan' &&
                  (message.toLowerCase().includes('loan') || message.toLowerCase().includes('mortgage'))) {
            // Process loan application
            processLoanApplication(message, extractedCustomerData);
            return;
        }
        
        console.log(`Processing message with workflow context: ${currentWorkflow}`);
        
        // Check if the message indicates a workflow change
        const messageLower = message.toLowerCase();
        const accountKeywords = ['account', 'open account', 'new account', 'checking', 'savings'];
        const loanKeywords = ['loan', 'borrow', 'mortgage', 'auto loan', 'personal loan'];
        const productKeywords = ['product', 'service', 'information', 'details', 'rates', 'fees'];
        
        // Try to detect workflow from message content
        let detectedWorkflow = currentWorkflow;
        
        // Only try to detect a new workflow if the message strongly indicates a workflow change
        if (accountKeywords.some(kw => messageLower.includes(kw)) && 
            (currentWorkflow !== 'account' || !currentWorkflow)) {
            console.log("Message suggests account workflow");
            detectedWorkflow = 'account';
        } else if (loanKeywords.some(kw => messageLower.includes(kw)) && 
                (currentWorkflow !== 'loan' || !currentWorkflow)) {
            console.log("Message suggests loan workflow");
            detectedWorkflow = 'loan';
        } else if (productKeywords.some(kw => messageLower.includes(kw)) && 
                (currentWorkflow !== 'products' || !currentWorkflow)) {
            console.log("Message suggests products workflow");
            detectedWorkflow = 'products';
        }
        
        // If workflow changed, update it
        if (detectedWorkflow !== currentWorkflow) {
            console.log(`Changing workflow from ${currentWorkflow} to ${detectedWorkflow}`);
            currentWorkflow = detectedWorkflow;
            // Reset conversation history when workflow changes
            conversationHistory = conversationHistory.slice(-2);
        }
            
        // Send message to backend for normal chat processing
        fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                conversation_history: conversationHistory,
                workflow: currentWorkflow
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Remove typing indicator
            removeTypingIndicator();

            // Add bot response to chat
            addMessage(data.response, 'bot');
            
            // Check if we need to reset the conversation
            if (data.reset === true) {
                console.log("RESET triggered from server - clearing conversation history");
                conversationHistory = [];
                currentWorkflow = null;
            }
            // Update workflow if it was changed by the backend
            else if (data.workflow && data.workflow !== currentWorkflow) {
                console.log(`Backend changed workflow to: ${data.workflow}`);
                currentWorkflow = data.workflow;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            removeTypingIndicator();
            addMessage('Sorry, I encountered an error processing your request. Please try again.', 'bot');
        });
    }
    
    // Function to handle account creation
    function processAccountCreation(message, customerData) {
        showTypingIndicator();
        
        // Determine account type from message
        let accountType = 'Basic Checking';
        if (message.toLowerCase().includes('premium checking')) {
            accountType = 'Premium Checking';
        } else if (message.toLowerCase().includes('essential savings')) {
            accountType = 'Essential Savings';
        } else if (message.toLowerCase().includes('premium savings')) {
            accountType = 'Premium Savings';
        } else if (message.toLowerCase().includes('savings')) {
            accountType = 'Essential Savings';
        }
        
        // Create account with extracted customer data
        fetch('/api/account-creation', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: customerData.name || '',
                dob: customerData.dob || '',
                address: customerData.address || '',
                email: customerData.email || '',
                phone: customerData.phone || '',
                document_type: 'ID',
                account_type: accountType
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Account creation failed');
            }
            return response.json();
        })
        .then(data => {
            removeTypingIndicator();
            
            if (data.status === 'success') {
                addMessage(`Great news! Your ${accountType} account has been created successfully. Your account number is ${data.account_number}. Is there anything else you'd like to know about your new account?`, 'bot');
            } else {
                addMessage(`I'm sorry, there was an issue creating your account: ${data.message}. Please try again later or speak with a bank representative.`, 'bot');
            }
        })
        .catch(error => {
            console.error('Error creating account:', error);
            removeTypingIndicator();
            addMessage('Sorry, I encountered an error processing your account request. Please try again.', 'bot');
        });
    }
    
    // Function to handle loan application
    function processLoanApplication(message, customerData) {
        showTypingIndicator();
        
        // Determine loan type from message
        let loanType = 'Personal Loan';
        let defaultAmount = 10000;
        let defaultTenure = 36;
        
        if (message.toLowerCase().includes('auto') || message.toLowerCase().includes('car')) {
            loanType = 'Auto Loan';
            defaultAmount = 25000;
            defaultTenure = 60;
        } else if (message.toLowerCase().includes('home') || message.toLowerCase().includes('mortgage')) {
            loanType = 'Home Mortgage';
            defaultAmount = 250000;
            defaultTenure = 360;
        }
        
        // Extract some default values for demo purposes
        const monthlyIncome = 5000; // This would be collected from the user in a real app
        
        // Submit loan application
        fetch('/api/loan-application', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                customer_data: {
                    name: customerData.name || '',
                    dob: customerData.dob || '',
                    address: customerData.address || '',
                    email: customerData.email || '',
                    phone: customerData.phone || ''
                },
                loan_type: loanType,
                loan_amount: defaultAmount,
                loan_tenure: defaultTenure,
                monthly_income: monthlyIncome
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Loan application failed');
            }
            return response.json();
        })
        .then(data => {
            removeTypingIndicator();
            
            if (data.status === 'Approved') {
                addMessage(`Congratulations! Your ${loanType} application has been approved. Your credit score is ${data.credit_score}. The loan application ID is ${data.loan_application_id}. Would you like to proceed with this loan offer?`, 'bot');
            } else if (data.status === 'Pending') {
                addMessage(`Thank you for applying for a ${loanType}. Your application is currently pending review. The loan application ID is ${data.loan_application_id}. We'll update you on its status soon.`, 'bot');
            } else {
                addMessage(`I'm sorry, your ${loanType} application was not approved at this time. You may wish to speak with one of our loan specialists for more options.`, 'bot');
            }
        })
        .catch(error => {
            console.error('Error processing loan application:', error);
            removeTypingIndicator();
            addMessage('Sorry, I encountered an error processing your loan request. Please try again.', 'bot');
        });
    }

    // Function to process uploaded document
    // Store extracted customer data for account/loan creation
    let extractedCustomerData = null;
    
    function processDocument(file) {
        // Show typing indicator
        showTypingIndicator();

        // Create FormData to send file
        const formData = new FormData();
        formData.append('document', file);
        
        // If we have a current workflow, add it to the document type
        if (currentWorkflow) {
            formData.append('document_type', currentWorkflow === 'account' ? 'ID' : 'Income');
        }

        // Send file to document scanning API
        fetch('/api/document-scanning', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Document scanning failed');
            }
            return response.json();
        })
        .then(data => {
            // Remove typing indicator
            removeTypingIndicator();

            if (data.status === 'success') {
                // Display extracted data
                const extractedData = data.extracted_data;
                
                const message = {
                    text: 'I\'ve successfully extracted the following information from your document:',
                    data: extractedData,
                    followup: 'Is this information correct? Would you like to proceed with this information?'
                };
                
                addMessage(message, 'bot');
                
                // Store the extracted data for later use
                extractedCustomerData = extractedData;
                
                // If we are in the account opening workflow, move to next step
                if (currentWorkflow === 'account') {
                    setTimeout(() => {
                        addMessage("What type of account would you like to open? We offer Basic Checking, Premium Checking, Essential Savings, and Premium Savings accounts.", 'bot');
                    }, 1500);
                } else if (currentWorkflow === 'loan') {
                    setTimeout(() => {
                        addMessage("Great! Now I need some information about the loan you'd like to apply for. What type of loan are you interested in? We offer Personal Loans, Auto Loans, and Home Mortgages.", 'bot');
                    }, 1500);
                }
            } else {
                addMessage(`I couldn't process your document: ${data.message}. Please try uploading a clearer image or enter your information manually.`, 'bot');
            }
        })
        .catch(error => {
            console.error('Error processing document:', error);
            removeTypingIndicator();
            addMessage('Sorry, I encountered an error processing your document. Please try again or enter your information manually.', 'bot');
        });
    }

    // Function to show typing indicator
    function showTypingIndicator() {
        const typingEl = document.createElement('div');
        typingEl.className = 'message bot typing-indicator';
        typingEl.innerHTML = `
            <div class="message-content">
                <div class="typing">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        `;
        chatMessages.appendChild(typingEl);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Function to remove typing indicator
    function removeTypingIndicator() {
        const typingIndicator = document.querySelector('.typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
});
