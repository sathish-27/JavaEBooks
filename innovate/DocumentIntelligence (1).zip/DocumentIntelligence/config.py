import os

# Azure OpenAI Configuration
AZURE_OPENAI_API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "mock-api-key")
AZURE_OPENAI_ENDPOINT = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://api.azure.com/openai/deployments/gpt-35-turbo")
AZURE_OPENAI_API_VERSION = os.environ.get("AZURE_OPENAI_API_VERSION", "2023-05-15")
AZURE_OPENAI_DEPLOYMENT_NAME = os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-35-turbo")

# Mock API Endpoints (for development)
DOCUMENT_SCANNING_API = "/api/document-scanning"
ID_VERIFICATION_API = "/api/id-verification"
COMPLIANCE_CHECK_API = "/api/compliance-check"
CREDIT_ASSESSMENT_API = "/api/credit-assessment"
ACCOUNT_CREATION_API = "/api/account-creation"
LOAN_UNDERWRITING_API = "/api/loan-underwriting"

# Bank Products Information (Sample data)
BANK_PRODUCTS = {
    "savings_accounts": [
        {
            "name": "Essential Savings",
            "interest_rate": "2.5%",
            "min_balance": "$500",
            "features": ["No monthly fees", "Online banking", "Mobile app access"]
        },
        {
            "name": "Premium Savings",
            "interest_rate": "3.2%",
            "min_balance": "$5,000",
            "features": ["Higher interest rates", "Free checkbook", "Priority customer service"]
        }
    ],
    "checking_accounts": [
        {
            "name": "Basic Checking",
            "monthly_fee": "$0",
            "min_balance": "$0",
            "features": ["Free debit card", "Online banking", "Mobile check deposit"]
        },
        {
            "name": "Premium Checking",
            "monthly_fee": "$15",
            "min_balance": "$2,500",
            "features": ["Fee waivers with minimum balance", "Overdraft protection", "ATM fee reimbursements"]
        }
    ],
    "loans": [
        {
            "name": "Home Mortgage",
            "interest_rate": "4.5% - 6.0%",
            "term": "15-30 years",
            "features": ["Competitive rates", "Various term options", "First-time homebuyer programs"]
        },
        {
            "name": "Auto Loan",
            "interest_rate": "3.9% - 5.5%",
            "term": "36-72 months",
            "features": ["Quick approval", "Flexible terms", "No prepayment penalties"]
        },
        {
            "name": "Personal Loan",
            "interest_rate": "7.99% - 15.99%",
            "term": "12-60 months",
            "features": ["No collateral required", "Fixed monthly payments", "Multiple use cases"]
        }
    ]
}
